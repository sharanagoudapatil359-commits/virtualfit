import { and, eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { cartItems, products, productSizes } from "@/db/schema";
import { ApiError, handler, ok, parseBody } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { getCart } from "@/lib/cart";
import { SIZES } from "@/lib/constants";

export const GET = handler(async () => {
  const user = await requireUser();
  return ok(await getCart(user.id));
});

const addSchema = z.object({
  productId: z.string().uuid(),
  size: z.enum(SIZES),
  qty: z.number().int().min(1).max(5).default(1),
});

export const POST = handler(async (req: Request) => {
  const user = await requireUser();
  const body = await parseBody(req, addSchema);

  const [product] = await db
    .select()
    .from(products)
    .where(and(eq(products.id, body.productId), eq(products.active, true)))
    .limit(1);
  if (!product) throw new ApiError(404, "PRODUCT_NOT_FOUND", "Product not found.");

  const [sizeRow] = await db
    .select()
    .from(productSizes)
    .where(
      and(eq(productSizes.productId, product.id), eq(productSizes.size, body.size)),
    )
    .limit(1);
  if (!sizeRow)
    throw new ApiError(400, "INVALID_SIZE", `Size ${body.size} is not offered for this item.`);

  const [existing] = await db
    .select()
    .from(cartItems)
    .where(
      and(
        eq(cartItems.userId, user.id),
        eq(cartItems.productId, product.id),
        eq(cartItems.size, body.size),
      ),
    )
    .limit(1);

  const nextQty = (existing?.qty ?? 0) + body.qty;
  if (nextQty > sizeRow.stock)
    throw new ApiError(409, "OUT_OF_STOCK", `Only ${sizeRow.stock} left in size ${body.size}.`, {
      available: sizeRow.stock,
    });

  if (existing) {
    await db.update(cartItems).set({ qty: nextQty }).where(eq(cartItems.id, existing.id));
  } else {
    await db
      .insert(cartItems)
      .values({ userId: user.id, productId: product.id, size: body.size, qty: body.qty });
  }
  return ok(await getCart(user.id), 201);
});
