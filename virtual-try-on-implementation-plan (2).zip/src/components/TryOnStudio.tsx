"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";
import {
  AlertTriangle,
  CheckCircle2,
  Heart,
  History,
  Loader2,
  ScanFace,
  Shirt,
  ShoppingBag,
  Sparkles,
  Trash2,
  Upload,
} from "lucide-react";
import type { ProductDto } from "@/lib/catalog";
import type { JobDto } from "@/lib/tryon/jobs";
import { money } from "@/lib/constants";
import { useToast } from "@/components/Toast";
import CompareSlider from "@/components/CompareSlider";

interface UploadState {
  id: string;
  url: string; // authenticated /api/files/<name>
  preview: string; // local object URL for instant feedback
  width: number;
  height: number;
}

type Lm = { x: number; y: number };
interface LmPoints {
  neck: Lm; leftShoulder: Lm; rightShoulder: Lm; chest: Lm; waist: Lm;
  leftHip: Lm; rightHip: Lm; leftKnee: Lm; rightKnee: Lm; leftAnkle: Lm; rightAnkle: Lm;
}

const ERROR_HINTS: Record<string, string> = {
  NO_PERSON: "Retake against a plain background with your full body — head to feet — in frame.",
  MULTIPLE_PEOPLE: "One person per photo. Crop the shot or retake it solo.",
  LOW_RESOLUTION: "Upload a larger photo (at least 480×560px). Any modern phone camera works.",
  UNCLEAR_POSE: "Face the camera with your arms slightly away from your body, in good light.",
  UNSUPPORTED_CATEGORY: "This garment category isn't supported by the try-on engine yet.",
  INVALID_SIZE: "That size isn't offered for this garment.",
  OUT_OF_STOCK: "That size just sold out — pick another.",
  MODEL_ERROR: "The try-on model hiccuped. Please try again in a moment.",
  TRYON_FAILED: "Something broke mid-render. Please retry.",
  UPLOAD_NOT_FOUND: "That upload is gone — please upload your photo again.",
  UPLOAD_FILE_MISSING: "The stored photo expired — please upload it again.",
  FILE_TOO_LARGE: "Keep photos under 8MB.",
  UNSUPPORTED_MEDIA_TYPE: "Use a JPEG, PNG or WebP photo.",
  MALFORMED_IMAGE: "That file doesn't look like a valid image.",
  IMAGE_TOO_SMALL: "Too small — we need at least 480×560px for landmark detection.",
  RATE_LIMITED: "Slow down a little — limits reset shortly.",
};

const WARNING_COPY: Record<string, string> = {
  NON_FRONTAL_POSE: "Best results when facing the camera directly.",
  LOW_CONFIDENCE: "Detection confidence was low — fit may be approximate.",
};

function LandmarkOverlay({ job }: { job: JobDto }) {
  const lm = job.landmarks as { width?: number; height?: number; points?: LmPoints } | null;
  if (!lm?.points || !lm.width || !lm.height) return null;
  const p = lm.points;
  const line = (a: Lm, b: Lm, key: string) => (
    <line key={key} x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke="#c6f24e" strokeWidth="4" opacity="0.85" strokeLinecap="round" />
  );
  return (
    <svg
      viewBox={`0 0 ${lm.width} ${lm.height}`}
      className="pointer-events-none absolute inset-0 h-full w-full"
      preserveAspectRatio="none"
    >
      {[
        [p.leftShoulder, p.rightShoulder, "sh"],
        [p.leftShoulder, p.leftHip, "l"],
        [p.rightShoulder, p.rightHip, "r"],
        [p.leftHip, p.rightHip, "hp"],
        [p.leftHip, p.leftAnkle, "ll"],
        [p.rightHip, p.rightAnkle, "rl"],
        [p.neck, p.waist, "sp"],
      ].map(([a, b, k]) => line(a as Lm, b as Lm, k as string))}
      {Object.values(p).map((pt, i) => (
        <g key={i}>
          <circle cx={pt.x} cy={pt.y} r={10} fill="#0b0b0d" opacity="0.7" />
          <circle cx={pt.x} cy={pt.y} r={6} fill="#c6f24e" />
        </g>
      ))}
    </svg>
  );
}

export default function TryOnStudio({ preselect }: { preselect?: string }) {
  const router = useRouter();
  const { push } = useToast();

  const [me, setMe] = useState<null | { name: string }>(null);
  const [upload, setUpload] = useState<UploadState | null>(null);
  const [uploading, setUploading] = useState(false);
  const [products, setProducts] = useState<ProductDto[]>([]);
  const [catFilter, setCatFilter] = useState<string>("all");
  const [product, setProduct] = useState<ProductDto | null>(null);
  const [size, setSize] = useState<string | null>(null);
  const [job, setJob] = useState<JobDto | null>(null);
  const [running, setRunning] = useState(false);
  const [err, setErr] = useState<{ code: string; message: string } | null>(null);
  const [showLandmarks, setShowLandmarks] = useState(true);
  const [history, setHistory] = useState<JobDto[]>([]);
  const [dragOver, setDragOver] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const loadHistory = useCallback(async () => {
    const res = await fetch("/api/tryon", { cache: "no-store" });
    if (res.ok) {
      const j = await res.json();
      setHistory(j.data.jobs.filter((x: JobDto) => x.status === "completed").reverse());
    }
  }, []);

  useEffect(() => {
    (async () => {
      const meRes = await fetch("/api/auth/me", { cache: "no-store" });
      if (meRes.ok) {
        const j = await meRes.json();
        setMe(j.data.user);
        loadHistory();
      }
      const pr = await fetch("/api/products", { cache: "no-store" });
      const pj = await pr.json();
      setProducts(pj.data.products);
      if (preselect) {
        const found = pj.data.products.find((p: ProductDto) => p.id === preselect);
        if (found) setProduct(found);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [preselect]);

  const setError = (code: string, message: string) => setErr({ code, message });

  /* -------------------- upload -------------------- */
  const onFile = async (file: File) => {
    setErr(null);
    setJob(null);
    const preview = URL.createObjectURL(file);
    setUploading(true);
    const fd = new FormData();
    fd.append("photo", file);
    const res = await fetch("/api/uploads", { method: "POST", body: fd });
    setUploading(false);
    if (res.status === 401) {
      push("Sign in to upload a photo.", "info");
      router.push("/login?next=/tryon");
      return;
    }
    if (!res.ok) {
      const j = await res.json().catch(() => null);
      const code = j?.error?.code ?? "TRYON_FAILED";
      setError(code, j?.error?.message ?? "Upload failed.");
      return;
    }
    const j = await res.json();
    setUpload({
      id: j.data.uploadId,
      url: j.data.url,
      preview,
      width: j.data.width,
      height: j.data.height,
    });
    push("Photo uploaded — stored privately.", "success");
  };

  const removeUpload = async () => {
    if (upload?.id) await fetch(`/api/uploads/${upload.id}`, { method: "DELETE" });
    setUpload(null);
    setJob(null);
    push("Photo deleted.", "info");
  };

  /* -------------------- run try-on -------------------- */
  const run = async () => {
    if (!upload) return setError("NO_FILE", "Upload a full-body photo first.");
    if (!product) return setError("NO_PRODUCT", "Pick a garment from the rail.");
    if (!size) return setError("INVALID_SIZE", "Choose a size.");
    setErr(null);
    setJob(null);
    setRunning(true);
    const res = await fetch("/api/tryon", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ uploadId: upload.id, productId: product.id, size }),
    });
    setRunning(false);
    const j = await res.json().catch(() => null);
    if (!res.ok) {
      setError(j?.error?.code ?? "TRYON_FAILED", j?.error?.message ?? "Try-on failed.");
      return;
    }
    setJob(j.data.job);
    push("Fit rendered.", "success");
    loadHistory();
  };

  const addToCart = async () => {
    if (!product || !size) return;
    const res = await fetch("/api/cart", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ productId: product.id, size, qty: 1 }),
    });
    if (res.ok) push("Added to cart.", "success");
    else push("Could not add to cart.", "error");
  };

  const openHistory = async (id: string) => {
    const res = await fetch(`/api/tryon/${id}`, { cache: "no-store" });
    if (!res.ok) return;
    const j = await res.json();
    const hj: JobDto = j.data.job;
    setJob(hj);
    setErr(null);
    if (hj.sourceUrl && hj.imageWidth && hj.imageHeight)
      setUpload({ id: "", url: hj.sourceUrl, preview: hj.sourceUrl, width: hj.imageWidth, height: hj.imageHeight });
  };

  const cats = ["all", ...new Set(products.map((p) => p.category?.slug ?? "other"))];
  const visible = catFilter === "all" ? products : products.filter((p) => p.category?.slug === catFilter);
  const inStockSizes = product?.sizes ?? [];

  const stepLabel = (n: string, t: string) => (
    <div className="mb-4 flex items-center gap-3">
      <span className="font-display text-xs font-bold text-lime">{n}</span>
      <h2 className="font-display text-sm font-bold uppercase tracking-[0.14em]">{t}</h2>
      <span className="h-px flex-1 bg-white/8" />
    </div>
  );

  return (
    <div className="grid gap-6 lg:grid-cols-12">
      {/* ---------- STEP 1 · PHOTO ---------- */}
      <section className="lg:col-span-4">
        {stepLabel("01", "Your photo")}
        {!upload ? (
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
            onDragLeave={() => setDragOver(false)}
            onDrop={(e) => {
              e.preventDefault();
              setDragOver(false);
              const f = e.dataTransfer.files?.[0];
              if (f) onFile(f);
            }}
            className={`flex aspect-[4/5] w-full flex-col items-center justify-center gap-4 rounded-3xl border-2 border-dashed transition ${
              dragOver ? "border-lime bg-lime/10" : "border-white/15 bg-panel hover:border-violet/50"
            }`}
          >
            {uploading ? (
              <Loader2 size={26} className="animate-spin text-lime" />
            ) : (
              <span className="grid h-14 w-14 place-items-center rounded-2xl bg-violet/15 text-violet">
                <Upload size={22} />
              </span>
            )}
            <span className="px-8 text-center text-sm text-mute">
              {uploading
                ? "Validating & storing…"
                : "Drop a full-body photo here, or tap to browse / use your camera"}
            </span>
            <span className="text-[11px] uppercase tracking-[0.18em] text-cream/30">
              JPEG · PNG · WebP · ≤ 8MB
            </span>
          </button>
        ) : (
          <div className="relative overflow-hidden rounded-3xl border border-white/10">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={upload.preview} alt="Your uploaded photo" className="block w-full" />
            {running && <div className="pointer-events-none absolute inset-0"><div className="scanline" /></div>}
            <div className="absolute bottom-3 left-3 right-3 flex items-center justify-between gap-2">
              {me && (
                <span className="rounded-full bg-ink/70 px-3 py-1 text-[10px] font-semibold tracking-[0.14em] text-cream/70 backdrop-blur">
                  PRIVATE · {me.name.toUpperCase()}
                </span>
              )}
              <button
                onClick={removeUpload}
                className="ml-auto grid h-8 w-8 place-items-center rounded-full bg-ink/70 text-ember backdrop-blur transition hover:bg-ember/20"
                title="Delete this photo"
              >
                <Trash2 size={14} />
              </button>
            </div>
          </div>
        )}
        <input
          ref={fileRef}
          type="file"
          accept="image/jpeg,image/png,image/webp"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) onFile(f);
            e.target.value = "";
          }}
        />
        <ul className="mt-4 space-y-1.5 text-xs text-mute">
          <li>• Front-facing, arms slightly out, head-to-feet visible</li>
          <li>• Plain background beats a busy one</li>
          <li>• EXIF stripped · delete anytime · never shared</li>
        </ul>
      </section>

      {/* ---------- STEP 2 · GARMENT ---------- */}
      <section className="lg:col-span-4">
        {stepLabel("02", "Garment & size")}
        <div className="mb-3 flex gap-2 overflow-x-auto pb-1">
          {cats.map((c) => (
            <button
              key={c}
              onClick={() => setCatFilter(c)}
              className={`whitespace-nowrap rounded-full border px-3 py-1 text-[11px] font-semibold uppercase tracking-[0.1em] transition ${
                catFilter === c ? "border-lime bg-lime text-ink" : "border-white/12 text-cream/60 hover:text-cream"
              }`}
            >
              {c}
            </button>
          ))}
        </div>
        <div className="grid max-h-[420px] grid-cols-2 gap-2.5 overflow-y-auto pr-1">
          {visible.map((p) => (
            <button
              key={p.id}
              type="button"
              onClick={() => { setProduct(p); setSize(null); }}
              className={`rounded-2xl border p-2 text-left transition ${
                product?.id === p.id ? "border-lime bg-lime/10" : "border-white/10 bg-panel hover:border-white/25"
              }`}
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={p.imageUrl} alt={p.name} className="aspect-square w-full object-contain" loading="lazy" />
              <p className="mt-1 truncate text-xs font-semibold">{p.name}</p>
              <p className="text-[11px] text-mute">{money(p.priceCents)}</p>
            </button>
          ))}
        </div>
        <div className="mt-4">
          <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.18em] text-mute">Size</p>
          <div className="flex flex-wrap gap-2">
            {product ? (
              inStockSizes.map((s) => (
                <button
                  key={s.size}
                  disabled={s.stock < 1}
                  onClick={() => setSize(s.size)}
                  className={`h-9 min-w-11 rounded-lg border px-2 text-xs font-bold transition ${
                    s.stock < 1
                      ? "cursor-not-allowed border-white/5 text-cream/25 line-through"
                      : size === s.size
                        ? "border-lime bg-lime text-ink"
                        : "border-white/15 text-cream/70 hover:border-cream/40"
                  }`}
                >
                  {s.size}
                </button>
              ))
            ) : (
              <span className="text-xs text-cream/30">Select a garment first</span>
            )}
          </div>
        </div>
        <button
          onClick={run}
          disabled={running || !upload || !product || !size}
          className="mt-6 flex w-full items-center justify-center gap-2 rounded-full bg-lime py-3.5 text-sm font-black uppercase tracking-[0.12em] text-ink transition hover:bg-cream disabled:cursor-not-allowed disabled:opacity-40"
        >
          {running ? <Loader2 size={16} className="animate-spin" /> : <ScanFace size={16} />}
          {running ? "Rendering fit…" : "Generate fit"}
        </button>
      </section>

      {/* ---------- STEP 3 · RESULT ---------- */}
      <section className="lg:col-span-4">
        {stepLabel("03", "Result")}
        {err && (
          <div className="rounded-3xl border border-ember/40 bg-ember/10 p-5">
            <div className="flex items-center gap-2 text-ember">
              <AlertTriangle size={16} />
              <p className="text-sm font-bold">{err.message}</p>
            </div>
            {ERROR_HINTS[err.code] && <p className="mt-2 text-xs leading-relaxed text-cream/70">{ERROR_HINTS[err.code]}</p>}
          </div>
        )}
        {!err && !job && (
          <div className="flex aspect-[4/5] flex-col items-center justify-center gap-3 rounded-3xl border border-dashed border-white/12 bg-panel/60 text-center">
            <Shirt size={26} className="text-cream/20" />
            <p className="max-w-[220px] text-xs text-mute">
              Complete steps 01 and 02, then generate. Your render appears here.
            </p>
          </div>
        )}
        {job && job.resultUrl && (
          <div>
            <CompareSlider
              before={job.sourceUrl ?? upload?.url ?? ""}
              after={job.resultUrl}
              overlay={showLandmarks ? <LandmarkOverlay job={job} /> : undefined}
            />
            <div className="mt-3 flex flex-wrap items-center gap-2">
              {job.processingMs != null && (
                <span className="rounded-full border border-white/10 px-2.5 py-1 text-[10px] font-semibold text-mute">
                  rendered in {job.processingMs}ms
                </span>
              )}
              {job.warnings.map((w) => (
                <span key={w} className="inline-flex items-center gap-1 rounded-full border border-ember/40 bg-ember/10 px-2.5 py-1 text-[10px] font-semibold text-ember">
                  <AlertTriangle size={10} /> {WARNING_COPY[w] ?? w}
                </span>
              ))}
              <button
                onClick={() => setShowLandmarks((v) => !v)}
                className={`ml-auto rounded-full border px-2.5 py-1 text-[10px] font-bold uppercase tracking-[0.1em] transition ${
                  showLandmarks ? "border-lime text-lime" : "border-white/15 text-mute"
                }`}
              >
                Pose debug
              </button>
            </div>
            <div className="mt-4 flex gap-2">
              <button onClick={addToCart} className="flex flex-1 items-center justify-center gap-2 rounded-full bg-cream py-2.5 text-xs font-bold uppercase tracking-[0.1em] text-ink transition hover:bg-lime">
                <ShoppingBag size={14} /> Add to cart
              </button>
              <button
                onClick={async () => {
                  if (!product) return;
                  await fetch("/api/wishlist", {
                    method: "POST",
                    headers: { "content-type": "application/json" },
                    body: JSON.stringify({ productId: product.id }),
                  });
                  push("Saved to wishlist.", "success");
                }}
                className="grid h-10 w-10 place-items-center rounded-full border border-white/15 text-cream/70 transition hover:border-ember/60 hover:text-ember"
                title="Save to wishlist"
              >
                <Heart size={15} />
              </button>
            </div>
          </div>
        )}
        {history.length > 0 && (
          <div className="mt-6">
            <p className="mb-2 flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-[0.18em] text-mute">
              <History size={12} /> Recent renders
            </p>
            <div className="flex gap-2 overflow-x-auto pb-1">
              {history.map((h) => (
                <button key={h.id} onClick={() => openHistory(h.id)} className="shrink-0 overflow-hidden rounded-xl border border-white/10 transition hover:border-lime/50">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={h.resultUrl!} alt={h.productName ?? "Render"} className="h-20 w-16 object-cover" loading="lazy" />
                </button>
              ))}
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
