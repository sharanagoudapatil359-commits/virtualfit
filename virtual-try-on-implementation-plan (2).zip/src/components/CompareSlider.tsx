"use client";

import { useState } from "react";
import { MoveHorizontal } from "lucide-react";

/**
 * Before/after comparison slider. The "after" layer (with optional
 * landmark overlay children) is clipped by the slider position.
 */
export default function CompareSlider({
  before,
  after,
  overlay,
}: {
  before: string;
  after: string;
  overlay?: React.ReactNode;
}) {
  const [pct, setPct] = useState(50);

  return (
    <div className="relative select-none overflow-hidden rounded-3xl border border-white/10 bg-panel">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={before} alt="Original photo" className="block w-full" draggable={false} />
      <div
        className="absolute inset-0"
        style={{ clipPath: `inset(0 ${100 - pct}% 0 0)` }}
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={after}
          alt="Virtual try-on result"
          className="absolute inset-0 h-full w-full object-cover"
          draggable={false}
        />
        {overlay}
      </div>

      {/* divider */}
      <div
        className="pointer-events-none absolute inset-y-0 w-0.5 bg-lime shadow-[0_0_16px_rgba(198,242,78,0.8)]"
        style={{ left: `${pct}%` }}
      >
        <span className="absolute left-1/2 top-1/2 grid h-9 w-9 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-lime text-ink">
          <MoveHorizontal size={16} strokeWidth={2.6} />
        </span>
      </div>

      <span className="absolute left-3 top-3 rounded-full bg-ink/70 px-2.5 py-1 text-[10px] font-bold tracking-[0.16em] text-cream/80 backdrop-blur">
        RESULT
      </span>
      <span className="absolute right-3 top-3 rounded-full bg-ink/70 px-2.5 py-1 text-[10px] font-bold tracking-[0.16em] text-cream/80 backdrop-blur">
        ORIGINAL
      </span>

      <input
        type="range"
        min={0}
        max={100}
        value={pct}
        onChange={(e) => setPct(Number(e.target.value))}
        aria-label="Compare original and try-on result"
        className="compare-range absolute inset-0 h-full w-full opacity-0"
      />
    </div>
  );
}
