import { describe, expect, it } from "vitest";
import { garmentSvg, shade } from "@/lib/tryon/garment";
import { SIZE_SCALE } from "@/lib/constants";

describe("garment renderer", () => {
  it("emits a sized svg with intrinsic dimensions", () => {
    const svg = garmentSvg("tee", "#4C6FFF", 200, 280);
    expect(svg).toContain('width="200"');
    expect(svg).toContain('height="280"');
    expect(svg).toContain("#4C6FFF");
    expect(svg).toContain("<svg");
  });

  it("supports all templates", () => {
    for (const t of ["tee", "dress", "pants", "skirt", "jacket"] as const) {
      expect(garmentSvg(t, "#123456", 100, 140)).toContain("<svg");
    }
  });

  it("shade() darkens and lightens", () => {
    expect(shade("#808080", 20)).toBe("#b3b3b3"); // +51 per channel
    expect(shade("#808080", -20)).toBe("#4d4d4d");
    expect(shade("#ffffff", 20)).toBe("#ffffff"); // clamps
  });

  it("size scale is monotonic", () => {
    const order = ["XS", "S", "M", "L", "XL", "XXL"] as const;
    for (let i = 1; i < order.length; i++)
      expect(SIZE_SCALE[order[i]]).toBeGreaterThan(SIZE_SCALE[order[i - 1]]);
  });
});
