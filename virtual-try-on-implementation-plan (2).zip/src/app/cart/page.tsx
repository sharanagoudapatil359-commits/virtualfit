"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import {
  ArrowRight,
  CheckCircle2,
  Loader2,
  Minus,
  PackageCheck,
  Plus,
  ShoppingBag,
  Trash2,
} from "lucide-react";
import { money } from "@/lib/constants";
import { useToast } from "@/components/Toast";

interface CartItem {
  id: string; productId: string; name: string; colorHex: string;
  imageUrl: string; size: string; qty: number; unitPriceCents: number; stock: number;
}
interface CartData {
  items: CartItem[];
  totals: { subtotalCents: number; shippingCents: number; taxCents: number; totalCents: number };
}

export default function CartPage() {
  const { push } = useToast();
  const [cart, setCart] = useState<CartData | null>(null);
  const [authed, setAuthed] = useState(true);
  const [busy, setBusy] = useState<string | null>(null);
  const [checkingOut, setCheckingOut] = useState(false);
  const [orderId, setOrderId] = useState<string | null>(null);

  const load = useCallback(async () => {
    const res = await fetch("/api/cart", { cache: "no-store" });
    if (res.status === 401) { setAuthed(false); return; }
    const j = await res.json();
    setCart(j.data);
  }, []);

  useEffect(() => { load(); }, [load]);

  const mutate = async (path: string, method: string, body?: unknown, key?: string) => {
    setBusy(key ?? path);
    const res = await fetch(path, {
      method,
      headers: body ? { "content-type": "application/json" } : undefined,
      body: body ? JSON.stringify(body) : undefined,
    });
    const j = await res.json().catch(() => null);
    setBusy(null);
    if (!res.ok) {
      push(j?.error?.message ?? "Cart update failed.", "error");
      return;
    }
    setCart(j.data);
  };

  const checkout = async () => {
    setCheckingOut(true);
    const res = await fetch("/api/orders", { method: "POST" });
    setCheckingOut(false);
    const j = await res.json().catch(() => null);
    if (!res.ok) {
      push(j?.error?.message ?? "Checkout failed.", "error");
      load();
      return;
    }
    setOrderId(j.data.order.id);
    setCart({ items: [], totals: { subtotalCents: 0, shippingCents: 0, taxCents: 0, totalCents: 0 } });
    push("Order placed. Thank you!", "success");
  };

  if (!authed)
    return (
      <div className="mx-auto max-w-md px-5 py-24 text-center">
        <ShoppingBag size={28} className="mx-auto text-cream/20" />
        <h1 className="mt-4 font-display text-2xl font-bold">Your cart is waiting</h1>
        <p className="mt-2 text-sm text-mute">Sign in to view and manage your cart.</p>
        <Link href="/login?next=/cart" className="mt-6 inline-flex items-center gap-2 rounded-full bg-lime px-6 py-3 text-sm font-bold text-ink hover:bg-cream">
          Sign in <ArrowRight size={15} />
        </Link>
      </div>
    );

  if (orderId)
    return (
      <div className="mx-auto max-w-md px-5 py-24 text-center">
        <CheckCircle2 size={44} className="mx-auto text-lime" />
        <h1 className="mt-5 font-display text-2xl font-bold">Order placed</h1>
        <p className="mt-2 text-sm text-mute">
          Order <span className="font-mono text-cream/80">{orderId.slice(0, 8).toUpperCase()}</span> is confirmed
          and stock has been reserved.
        </p>
        <Link href="/catalog" className="mt-6 inline-flex items-center gap-2 rounded-full bg-cream px-6 py-3 text-sm font-bold text-ink hover:bg-lime">
          Keep shopping <ArrowRight size={15} />
        </Link>
      </div>
    );

  const items = cart?.items ?? [];

  return (
    <div className="mx-auto max-w-5xl px-5 py-12">
      <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.24em] text-violet">Cart</p>
      <h1 className="font-display text-3xl font-extrabold">Order summary</h1>

      {cart === null ? (
        <div className="mt-16 flex justify-center"><Loader2 className="animate-spin text-lime" /></div>
      ) : items.length === 0 ? (
        <div className="mt-10 rounded-3xl border border-dashed border-white/15 p-16 text-center">
          <ShoppingBag size={26} className="mx-auto text-cream/20" />
          <p className="mt-4 font-display text-lg">Nothing here yet.</p>
          <Link href="/catalog" className="mt-4 inline-block text-sm text-lime hover:underline">
            Browse the catalog →
          </Link>
        </div>
      ) : (
        <div className="mt-8 grid gap-8 lg:grid-cols-[1fr_320px]">
          <ul className="space-y-3">
            {items.map((it) => (
              <li key={it.id} className="flex items-center gap-4 rounded-3xl border border-white/8 bg-panel p-4">
                <div
                  className="grid h-20 w-16 shrink-0 place-items-center overflow-hidden rounded-2xl"
                  style={{ background: `${it.colorHex}22` }}
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={it.imageUrl} alt={it.name} className="h-full w-full object-contain p-1.5" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold">{it.name}</p>
                  <p className="mt-0.5 text-xs text-mute">
                    Size {it.size} · {money(it.unitPriceCents)}
                    {it.stock <= it.qty && <span className="ml-2 text-ember">max stock</span>}
                  </p>
                  <div className="mt-2 inline-flex items-center gap-3 rounded-full border border-white/10 px-2 py-1">
                    <button
                      disabled={busy === it.id || it.qty <= 1}
                      onClick={() => mutate(`/api/cart/${it.id}`, "PATCH", { qty: it.qty - 1 }, it.id)}
                      className="text-cream/60 hover:text-cream disabled:opacity-30"
                      aria-label="Decrease quantity"
                    >
                      <Minus size={13} />
                    </button>
                    <span className="min-w-4 text-center text-xs font-bold">{it.qty}</span>
                    <button
                      disabled={busy === it.id || it.qty >= it.stock || it.qty >= 5}
                      onClick={() => mutate(`/api/cart/${it.id}`, "PATCH", { qty: it.qty + 1 }, it.id)}
                      className="text-cream/60 hover:text-cream disabled:opacity-30"
                      aria-label="Increase quantity"
                    >
                      <Plus size={13} />
                    </button>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold text-lime">{money(it.unitPriceCents * it.qty)}</p>
                  <button
                    disabled={busy === it.id}
                    onClick={() => mutate(`/api/cart/${it.id}`, "DELETE", undefined, it.id)}
                    className="mt-2 inline-grid h-8 w-8 place-items-center rounded-full border border-white/10 text-cream/50 transition hover:border-ember/50 hover:text-ember"
                    aria-label="Remove item"
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
              </li>
            ))}
          </ul>

          <aside className="h-fit rounded-3xl border border-white/8 bg-panel p-6">
            <h2 className="mb-4 text-sm font-bold uppercase tracking-[0.14em] text-mute">Summary</h2>
            <dl className="space-y-2.5 text-sm">
              <div className="flex justify-between"><dt className="text-mute">Subtotal</dt><dd>{money(cart.totals.subtotalCents)}</dd></div>
              <div className="flex justify-between"><dt className="text-mute">Shipping</dt><dd>{cart.totals.shippingCents === 0 ? "Free" : money(cart.totals.shippingCents)}</dd></div>
              <div className="flex justify-between"><dt className="text-mute">Tax (8%)</dt><dd>{money(cart.totals.taxCents)}</dd></div>
              <div className="mt-2 flex justify-between border-t border-white/10 pt-3 text-base font-bold">
                <dt>Total</dt><dd className="text-lime">{money(cart.totals.totalCents)}</dd>
              </div>
            </dl>
            <button
              onClick={checkout}
              disabled={checkingOut}
              className="mt-6 flex w-full items-center justify-center gap-2 rounded-full bg-lime py-3 text-sm font-black uppercase tracking-[0.1em] text-ink transition hover:bg-cream disabled:opacity-50"
            >
              {checkingOut ? <Loader2 size={15} className="animate-spin" /> : <PackageCheck size={15} />}
              Checkout
            </button>
            <p className="mt-3 text-center text-[11px] text-mute">
              Free shipping over $75 · stock reserved at checkout
            </p>
          </aside>
        </div>
      )}
    </div>
  );
}
