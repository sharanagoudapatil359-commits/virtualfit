import sharp from "sharp";
import type { GarmentTemplate, SizeLabel } from "@/lib/constants";
import { getTryOnModel, type TryOnModel } from "@/lib/tryon/model";
import { detectPose, type PoseResult } from "@/lib/tryon/pose";

/**
 * Try-on pipeline: preprocess → pose detection → model inference.
 * Pure and dependency-injected so tests can swap the detector/model.
 */

export interface PipelineInput {
  photo: Buffer;
  garment: { template: GarmentTemplate; colorHex: string; name: string };
  size: SizeLabel;
}

export interface PipelineOutput {
  result: Buffer; // JPEG
  width: number;
  height: number;
  pose: PoseResult;
  modelName: string;
  processingMs: number;
}

async function preprocess(
  photo: Buffer,
): Promise<{ buffer: Buffer; width: number; height: number }> {
  const out = await sharp(photo)
    .rotate()
    .resize({ width: 1600, withoutEnlargement: true })
    .jpeg({ quality: 90 })
    .toBuffer({ resolveWithObject: true });
  return { buffer: out.data, width: out.info.width, height: out.info.height };
}

export async function runTryOnPipeline(
  input: PipelineInput,
  model: TryOnModel = getTryOnModel(),
  detect: typeof detectPose = detectPose,
): Promise<PipelineOutput> {
  const t0 = Date.now();
  const img = await preprocess(input.photo);
  const pose = await detect(img.buffer); // throws PoseError with a code
  const out = await model.tryOn({
    image: img.buffer,
    width: img.width,
    height: img.height,
    pose,
    garment: input.garment,
    size: input.size,
  });
  return {
    result: out.image,
    width: img.width,
    height: img.height,
    pose,
    modelName: model.name,
    processingMs: Date.now() - t0,
  };
}

/** Preprocessed photos are capped at this width before detection. */
export const MAX_PIPELINE_DIM = 1600;
