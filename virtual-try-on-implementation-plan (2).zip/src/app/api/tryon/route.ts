import { and, desc, eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { products, productSizes, tryonJobs, uploads } from "@/db/schema";
import { ApiError, handler, ok, parseBody } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { config } from "@/lib/config";
import { GARMENT_TEMPLATES, SIZES, type GarmentTemplate } from "@/lib/constants";
import { clientIp, rateLimit } from "@/lib/ratelimit";
import { readStoredFile, writeResultFile } from "@/lib/uploads";
import { jobDto } from "@/lib/tryon/jobs";
import { runTryOnPipeline } from "@/lib/tryon/pipeline";
import { PoseError } from "@/lib/tryon/pose";
import { TryOnModelError } from "@/lib/tryon/model";

const tryonSchema = z.object({
  uploadId: z.string().uuid(),
  productId: z.string().uuid(),
  size: z.enum(SIZES),
});

/**
 * POST /api/tryon { uploadId, productId, size }
 * Runs preprocess → pose detection → garment overlay and returns the job.
 * All expected failure modes are mapped to explicit codes/HTTP statuses:
 *   400 UNSUPPORTED_CATEGORY | 400 INVALID_SIZE | 404 UPLOAD_NOT_FOUND
 *   404 PRODUCT_NOT_FOUND    | 409 OUT_OF_STOCK  | 422 <PoseError.code>
 *   502 MODEL_ERROR
 */
export const POST = handler(async (req: Request) => {
  const user = await requireUser();
  rateLimit(`tryon:${clientIp(req)}:${user.id}`, config.limits.tryon, 60 * 60 * 1000);
  const body = await parseBody(req, tryonSchema);

  // Ownership check: 404 either way to avoid leaking existence.
  const [upload] = await db
    .select()
    .from(uploads)
    .where(and(eq(uploads.id, body.uploadId), eq(uploads.userId, user.id)))
    .limit(1);
  if (!upload) throw new ApiError(404, "UPLOAD_NOT_FOUND", "Upload not found.");

  const [product] = await db
    .select()
    .from(products)
    .where(and(eq(products.id, body.productId), eq(products.active, true)))
    .limit(1);
  if (!product) throw new ApiError(404, "PRODUCT_NOT_FOUND", "Product not found.");

  if (!(GARMENT_TEMPLATES as readonly string[]).includes(product.garmentTemplate))
    throw new ApiError(
      400,
      "UNSUPPORTED_CATEGORY",
      `Virtual try-on is not supported for "${product.garmentTemplate}" items yet.`,
    );

  const [sizeRow] = await db
    .select()
    .from(productSizes)
    .where(
      and(eq(productSizes.productId, product.id), eq(productSizes.size, body.size)),
    )
    .limit(1);
  if (!sizeRow)
    throw new ApiError(400, "INVALID_SIZE", `Size ${body.size} is not offered for this item.`);
  if (sizeRow.stock < 1)
    throw new ApiError(409, "OUT_OF_STOCK", `Size ${body.size} is out of stock.`);

  const photo = await readStoredFile(upload.fileName, "upload");
  if (!photo)
    throw new ApiError(404, "UPLOAD_FILE_MISSING", "The uploaded photo is no longer available.");

  const [job] = await db
    .insert(tryonJobs)
    .values({
      userId: user.id,
      uploadId: upload.id,
      productId: product.id,
      size: body.size,
      status: "processing",
    })
    .returning();

  try {
    const out = await runTryOnPipeline({
      photo,
      garment: {
        template: product.garmentTemplate as GarmentTemplate,
        colorHex: product.colorHex,
        name: product.name,
      },
      size: body.size,
    });
    const resultFile = `r_${job.id}.jpg`;
    await writeResultFile(resultFile, out.result);
    const [done] = await db
      .update(tryonJobs)
      .set({
        status: "completed",
        resultFile,
        landmarks: { width: out.width, height: out.height, points: out.pose.landmarks },
        warnings: out.pose.warnings,
        processingMs: out.processingMs,
        updatedAt: new Date(),
      })
      .where(eq(tryonJobs.id, job.id))
      .returning();
    return ok(
      {
        job: jobDto(done, {
          productName: product.name,
          productColorHex: product.colorHex,
          sourceFile: upload.fileName,
        }),
      },
      201,
    );
  } catch (e) {
    const code =
      e instanceof PoseError
        ? e.code
        : e instanceof TryOnModelError
          ? "MODEL_ERROR"
          : "TRYON_FAILED";
    const message = e instanceof Error ? e.message : "Try-on failed unexpectedly.";
    await db
      .update(tryonJobs)
      .set({ status: "failed", errorCode: code, errorMessage: message, updatedAt: new Date() })
      .where(eq(tryonJobs.id, job.id));
    const status = e instanceof PoseError ? 422 : e instanceof TryOnModelError ? 502 : 500;
    throw new ApiError(status, code, message, { jobId: job.id });
  }
});

/** GET /api/tryon — current user's recent try-on jobs. */
export const GET = handler(async () => {
  const user = await requireUser();
  const rows = await db
    .select({ j: tryonJobs, name: products.name, color: products.colorHex })
    .from(tryonJobs)
    .innerJoin(products, eq(products.id, tryonJobs.productId))
    .where(eq(tryonJobs.userId, user.id))
    .orderBy(desc(tryonJobs.createdAt))
    .limit(12);
  return ok({
    jobs: rows.map((r) =>
      jobDto(r.j, { productName: r.name, productColorHex: r.color }),
    ),
  });
});
