import { db } from "@/db";
import { uploads } from "@/db/schema";
import { ApiError, handler, ok } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { config } from "@/lib/config";
import { rateLimit } from "@/lib/ratelimit";
import { saveUserPhoto } from "@/lib/uploads";

/**
 * POST /api/uploads — multipart form-data, field "photo".
 * Validates mime (magic bytes), size, dimensions; stores outside web root.
 */
export const POST = handler(async (req: Request) => {
  const user = await requireUser();
  rateLimit(`upload:${user.id}`, config.limits.upload, 60 * 60 * 1000);

  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    throw new ApiError(400, "INVALID_FORM", "Expected multipart/form-data.");
  }
  const file = form.get("photo");
  if (!(file instanceof File))
    throw new ApiError(400, "NO_FILE", 'Attach the photo in a "photo" file field.');
  if (file.size > config.maxUploadBytes)
    throw new ApiError(
      413,
      "FILE_TOO_LARGE",
      `Photo exceeds the ${Math.round(config.maxUploadBytes / 1024 / 1024)}MB limit.`,
    );

  const buffer = Buffer.from(await file.arrayBuffer());
  const stored = await saveUserPhoto(buffer); // throws 415/422/413 ApiErrors
  const [row] = await db
    .insert(uploads)
    .values({
      userId: user.id,
      fileName: stored.fileName,
      mime: "image/jpeg",
      width: stored.width,
      height: stored.height,
      bytes: stored.bytes,
      sha256: stored.sha256,
    })
    .returning();

  return ok(
    {
      uploadId: row.id,
      url: `/api/files/${row.fileName}`,
      width: row.width,
      height: row.height,
    },
    201,
  );
});
