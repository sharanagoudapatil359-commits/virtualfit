/**
 * Seed script: `npx tsx scripts/seed.ts`
 * Creates categories, demo products (with per-size stock), and two users:
 *   admin@virtualfit.dev / admin12345   (role: admin)
 *   demo@virtualfit.dev  / demo12345    (role: user)
 * Idempotent. The same routine also runs automatically at server boot
 * via instrumentation.ts, so manual seeding is optional.
 */
import "dotenv/config";
import { ensureSeed } from "../src/db/seed";

ensureSeed()
  .then(() => {
    console.log("Seed complete.");
    process.exit(0);
  })
  .catch((e) => {
    console.error(e);
    process.exit(1);
  });
