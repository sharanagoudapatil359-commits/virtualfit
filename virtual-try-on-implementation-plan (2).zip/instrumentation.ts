/**
 * Next.js startup hook — runs once per Node.js server boot.
 * Self-heals the database (schema + demo seed) so a freshly provisioned
 * preview environment never renders a broken app.
 */
export async function register() {
  if (process.env.NEXT_RUNTIME === "nodejs") {
    try {
      const { bootstrapDatabase } = await import("./src/db/bootstrap");
      await bootstrapDatabase();
    } catch (e) {
      console.error("[bootstrap] non-fatal:", e);
    }
  }
}
