/** Order math — pure functions so they are trivially unit-testable. */

export const FREE_SHIPPING_THRESHOLD = 7500; // cents
export const SHIPPING_FLAT = 699;
export const TAX_RATE = 0.08;

export interface Totals {
  subtotalCents: number;
  shippingCents: number;
  taxCents: number;
  totalCents: number;
}

export function computeTotals(
  items: { unitPriceCents: number; qty: number }[],
): Totals {
  const subtotalCents = items.reduce(
    (sum, i) => sum + i.unitPriceCents * i.qty,
    0,
  );
  const shippingCents =
    subtotalCents === 0 || subtotalCents >= FREE_SHIPPING_THRESHOLD
      ? 0
      : SHIPPING_FLAT;
  const taxCents = Math.round(subtotalCents * TAX_RATE);
  return {
    subtotalCents,
    shippingCents,
    taxCents,
    totalCents: subtotalCents + shippingCents + taxCents,
  };
}
