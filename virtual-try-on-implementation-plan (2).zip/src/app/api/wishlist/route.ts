import { and, desc, eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { products, wishlistItems } from "@/db/schema";
import { ApiError, handler, ok, parseBody } from "@/lib/api";
import { requireUser } from "@/lib/auth";

export const GET = handler(async () => {
  const user = await requireUser();
  const rows = await db
    .select({
      id: wishlistItems.id,
      productId: products.id,
      name: products.name,
      colorHex: products.colorHex,
      template: products.garmentTemplate,
      priceCents: products.priceCents,
      addedAt: wishlistItems.addedAt,
    })
    .from(wishlistItems)
    .innerJoin(products, eq(products.id, wishlistItems.productId))
    .where(eq(wishlistItems.userId, user.id))
    .orderBy(desc(wishlistItems.addedAt));
  return ok({
    items: rows.map((r) => ({
      ...r,
      imageUrl: `/api/products/${r.productId}/image`,
      addedAt: r.addedAt.toISOString(),
    })),
  });
});

const schema = z.object({ productId: z.string().uuid() });

export const POST = handler(async (req: Request) => {
  const user = await requireUser();
  const { productId } = await parseBody(req, schema);
  const [p] = await db
    .select({ id: products.id })
    .from(products)
    .where(and(eq(products.id, productId), eq(products.active, true)))
    .limit(1);
  if (!p) throw new ApiError(404, "PRODUCT_NOT_FOUND", "Product not found.");

  const inserted = await db
    .insert(wishlistItems)
    .values({ userId: user.id, productId })
    .onConflictDoNothing()
    .returning();
  return ok({ added: inserted.length > 0 }, inserted.length ? 201 : 200);
});

export const DELETE = handler(async (req: Request) => {
  const user = await requireUser();
  const { productId } = await parseBody(req, schema);
  await db
    .delete(wishlistItems)
    .where(
      and(eq(wishlistItems.userId, user.id), eq(wishlistItems.productId, productId)),
    );
  return ok({ removed: true });
});
