import { and, desc, eq, ilike, inArray } from "drizzle-orm";
import { db } from "@/db";
import {
  categories,
  products,
  productSizes,
  type Category,
  type Product,
} from "@/db/schema";

export interface ProductDto {
  id: string;
  name: string;
  description: string;
  colorHex: string;
  template: string;
  priceCents: number;
  category: { slug: string; name: string } | null;
  sizes: { size: string; stock: number }[];
  imageUrl: string;
}

export function toProductDto(
  p: Product,
  c: Category | null,
  sizes: { size: string; stock: number }[],
): ProductDto {
  return {
    id: p.id,
    name: p.name,
    description: p.description,
    colorHex: p.colorHex,
    template: p.garmentTemplate,
    priceCents: p.priceCents,
    category: c ? { slug: c.slug, name: c.name } : null,
    sizes: sizes
      .map((s) => ({ size: s.size, stock: s.stock }))
      .sort((a, b) => a.size.localeCompare(b.size)),
    imageUrl: `/api/products/${p.id}/image`,
  };
}

export async function attachSizes(rows: { p: Product; c: Category | null }[]) {
  const ids = rows.map((r) => r.p.id);
  const sizeRows = ids.length
    ? await db
        .select()
        .from(productSizes)
        .where(inArray(productSizes.productId, ids))
    : [];
  return rows.map((r) =>
    toProductDto(
      r.p,
      r.c,
      sizeRows.filter((s) => s.productId === r.p.id),
    ),
  );
}

export async function listProducts(filter: {
  categorySlug?: string | null;
  q?: string | null;
}) {
  const conds = [eq(products.active, true)];
  if (filter.categorySlug) conds.push(eq(categories.slug, filter.categorySlug));
  if (filter.q) conds.push(ilike(products.name, `%${filter.q}%`));
  const rows = await db
    .select({ p: products, c: categories })
    .from(products)
    .leftJoin(categories, eq(categories.id, products.categoryId))
    .where(and(...conds))
    .orderBy(desc(products.createdAt));
  return attachSizes(rows);
}

export async function listCategories() {
  return db.select().from(categories).orderBy(categories.sortOrder);
}
