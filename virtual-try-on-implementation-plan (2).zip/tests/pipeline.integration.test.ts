import { describe, expect, it } from "vitest";
import sharp from "sharp";
import { runTryOnPipeline } from "@/lib/tryon/pipeline";
import { OverlayTryOnModel } from "@/lib/tryon/model";
import { PoseError } from "@/lib/tryon/pose";

/**
 * Integration: photo → preprocess → pose → garment overlay → JPEG result.
 * Uses a synthetic but realistic "person on plain background" fixture so
 * no external files or network are needed.
 */
async function fixturePhoto(w = 720, h = 1280, colour = "#2e2e38"): Promise<Buffer> {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}">
    <rect width="100%" height="100%" fill="#c9c9ce"/>
    <circle cx="${w / 2}" cy="120" r="70" fill="${colour}"/>
    <rect x="${w / 2 - 70}" y="200" width="140" height="420" rx="30" fill="${colour}"/>
    <rect x="${w / 2 - 60}" y="600" width="55" height="520" rx="20" fill="${colour}"/>
    <rect x="${w / 2 + 5}" y="600" width="55" height="520" rx="20" fill="${colour}"/>
  </svg>`;
  return sharp(Buffer.from(svg)).jpeg({ quality: 95 }).toBuffer();
}

describe("try-on pipeline (synthetic end-to-end)", () => {
  it("returns a composited JPEG with landmarks and sane timing", async () => {
    const photo = await fixturePhoto();
    const out = await runTryOnPipeline(
      { photo, garment: { template: "tee", colorHex: "#4c6fff", name: "Test Tee" }, size: "M" },
      new OverlayTryOnModel(),
    );
    expect(out.result.length).toBeGreaterThan(10_000);
    expect(out.result[0]).toBe(0xff); // JPEG SOI
    expect(out.result[1]).toBe(0xd8);
    expect(out.width).toBe(720);
    expect(out.height).toBe(1280);
    expect(out.modelName).toBe("overlay-v1");
    const L = out.pose.landmarks;
    expect(L.leftShoulder.x).toBeLessThan(L.rightShoulder.x);
    expect(L.leftShoulder.y).toBeLessThan(L.waist.y);
    expect(out.processingMs).toBeLessThan(10_000);
  });

  it("renders lower-body garments too", async () => {
    const photo = await fixturePhoto();
    const out = await runTryOnPipeline(
      { photo, garment: { template: "pants", colorHex: "#4a5d7e", name: "Denim" }, size: "L" },
      new OverlayTryOnModel(),
    );
    expect(out.result[0]).toBe(0xff);
    expect(out.result[1]).toBe(0xd8);
  });

  it("throws NO_PERSON for a blank background", async () => {
    const blank = await sharp({
      create: { width: 720, height: 1280, channels: 3, background: "#c9c9ce" },
    })
      .jpeg()
      .toBuffer();
    await expect(
      runTryOnPipeline(
        { photo: blank, garment: { template: "tee", colorHex: "#111111", name: "X" }, size: "M" },
        new OverlayTryOnModel(),
      ),
    ).rejects.toMatchObject({ code: "NO_PERSON" } satisfies Partial<PoseError>);
  });

  it("throws LOW_RESOLUTION for tiny photos", async () => {
    const small = await fixturePhoto(200, 320);
    await expect(
      runTryOnPipeline(
        { photo: small, garment: { template: "tee", colorHex: "#111111", name: "X" }, size: "M" },
        new OverlayTryOnModel(),
      ),
    ).rejects.toMatchObject({ code: "LOW_RESOLUTION" } satisfies Partial<PoseError>);
  });
});
