import bcrypt from "bcryptjs";
import { config } from "@/lib/config";

/** Password hashing — isolated from DB so it can be unit-tested standalone. */
export async function hashPassword(plain: string): Promise<string> {
  return bcrypt.hash(plain, config.bcryptRounds);
}

export async function verifyPassword(plain: string, hash: string): Promise<boolean> {
  return bcrypt.compare(plain, hash);
}
