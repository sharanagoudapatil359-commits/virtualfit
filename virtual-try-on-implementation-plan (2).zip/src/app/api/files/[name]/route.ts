import { eq } from "drizzle-orm";
import { db } from "@/db";
import { tryonJobs, uploads } from "@/db/schema";
import { fail } from "@/lib/api";
import { getSessionUser } from "@/lib/auth";
import { readStoredFile } from "@/lib/uploads";

type Ctx = { params: Promise<{ name: string }> };

/**
 * GET /api/files/:name — streams a stored image.
 * User photos & try-on results are private: owner (or admin) only.
 * Filenames are random UUIDs; traversal is blocked in readStoredFile.
 */
export async function GET(_req: Request, ctx: Ctx) {
  const { name } = await ctx.params;
  const user = await getSessionUser();
  if (!user) return fail(401, "AUTH_REQUIRED", "Please sign in.");

  const [up] = await db.select().from(uploads).where(eq(uploads.fileName, name)).limit(1);
  let kind: "upload" | "result" = "upload";
  let ownerId: string | null = up?.userId ?? null;

  if (!up) {
    const [job] = await db
      .select({ userId: tryonJobs.userId })
      .from(tryonJobs)
      .where(eq(tryonJobs.resultFile, name))
      .limit(1);
    if (!job) return fail(404, "FILE_NOT_FOUND", "File not found.");
    kind = "result";
    ownerId = job.userId;
  }

  if (ownerId !== user.id && user.role !== "admin")
    return fail(403, "FORBIDDEN", "You do not have access to this file.");

  const data = await readStoredFile(name, kind);
  if (!data) return fail(404, "FILE_GONE", "The file is no longer available.");

  return new Response(new Uint8Array(data), {
    headers: {
      "content-type": "image/jpeg",
      "cache-control": "private, no-store",
      "x-content-type-options": "nosniff",
    },
  });
}
