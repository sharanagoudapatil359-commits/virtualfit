import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { tryonJobs, uploads } from "@/db/schema";
import { ApiError, handler, ok } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { jobDto } from "@/lib/tryon/jobs";

type Ctx = { params: Promise<{ id: string }> };

/** GET /api/tryon/:id — poll a job (async-ready for a real model worker). */
export const GET = handler(async (_req: Request, ctx: Ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const cond =
    user.role === "admin"
      ? eq(tryonJobs.id, id)
      : and(eq(tryonJobs.id, id), eq(tryonJobs.userId, user.id));
  const [job] = await db.select().from(tryonJobs).where(cond).limit(1);
  if (!job) throw new ApiError(404, "JOB_NOT_FOUND", "Try-on job not found.");
  const [up] = await db.select().from(uploads).where(eq(uploads.id, job.uploadId)).limit(1);
  return ok({ job: jobDto(job, { sourceFile: up?.fileName }) });
});
