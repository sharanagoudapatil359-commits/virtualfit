import sharp from "sharp";
import { config } from "@/lib/config";
import {
  SIZE_SCALE,
  TEMPLATE_REGION,
  type GarmentTemplate,
  type SizeLabel,
} from "@/lib/constants";
import { garmentSvg } from "@/lib/tryon/garment";
import type { PoseResult } from "@/lib/tryon/pose";

/* ================================================================== */
/*  PLUGGABLE AI VIRTUAL TRY-ON MODEL                                  */
/* ================================================================== */
/*  This interface is THE swap-in point for a real generative model    */
/*  (VTON diffusion model, vendor API, or a FastAPI sidecar running    */
/*  MediaPipe + try-on inference). Implementations:                    */
/*    - OverlayTryOnModel  (default): landmark-anchored garment warp   */
/*    - HttpTryOnModel     (TRYON_PROVIDER=http): POSTs the photo +    */
/*      landmarks to TRYON_API_URL and expects a composited image.     */
/* ================================================================== */

export interface TryOnInput {
  image: Buffer; // preprocessed user photo (JPEG)
  width: number;
  height: number;
  pose: PoseResult;
  garment: { template: GarmentTemplate; colorHex: string; name: string };
  size: SizeLabel;
}

export interface TryOnOutput {
  image: Buffer;
  mime: "image/jpeg";
  meta: { overlayBox: { x: number; y: number; width: number; height: number } };
}

export interface TryOnModel {
  readonly name: string;
  tryOn(input: TryOnInput): Promise<TryOnOutput>;
}

export class TryOnModelError extends Error {
  constructor(message: string) {
    super(message);
  }
}

/* ------------------------------------------------------------------ */
/* Default: geometric garment overlay driven by pose landmarks.        */
/* ------------------------------------------------------------------ */
export class OverlayTryOnModel implements TryOnModel {
  readonly name = "overlay-v1";

  async tryOn(input: TryOnInput): Promise<TryOnOutput> {
    const { pose, garment, size, width: imgW, height: imgH } = input;
    const L = pose.landmarks;
    const scale = SIZE_SCALE[size];
    const region = TEMPLATE_REGION[garment.template];

    const shCx = (L.leftShoulder.x + L.rightShoulder.x) / 2;
    const shY = (L.leftShoulder.y + L.rightShoulder.y) / 2;
    const shW = Math.abs(L.rightShoulder.x - L.leftShoulder.x);
    const hipCx = (L.leftHip.x + L.rightHip.x) / 2;
    const hipY = (L.leftHip.y + L.rightHip.y) / 2;
    const hipW = Math.abs(L.rightHip.x - L.leftHip.x);
    const tiltDeg =
      (Math.atan2(L.rightShoulder.y - L.leftShoulder.y, L.rightShoulder.x - L.leftShoulder.x) *
        180) /
      Math.PI;

    let w: number, h: number, x: number, y: number;
    if (region === "upper") {
      w = shW * (garment.template === "jacket" ? 1.7 : 1.55) * scale;
      h = Math.max(1, (L.waist.y - shY) * (garment.template === "jacket" ? 1.55 : 1.45));
      x = shCx - w / 2;
      y = shY - h * 0.05;
    } else if (region === "full") {
      const kneeY = (L.leftKnee.y + L.rightKnee.y) / 2;
      w = shW * 1.7 * scale;
      h = Math.max(1, (kneeY - shY) * 1.25);
      x = shCx - w / 2;
      y = shY - h * 0.03;
    } else {
      const ankleY = (L.leftAnkle.y + L.rightAnkle.y) / 2;
      const kneeY = (L.leftKnee.y + L.rightKnee.y) / 2;
      if (garment.template === "pants") {
        w = hipW * 1.5 * scale;
        h = Math.max(1, ankleY - hipY + hipW * 0.12);
        y = hipY - h * 0.05;
      } else {
        w = hipW * 1.6 * scale;
        h = Math.max(1, (kneeY - hipY) * 1.15);
        y = hipY - h * 0.04;
      }
      x = hipCx - w / 2;
    }

    if (![w, h, x, y].every(Number.isFinite) || w < 8 || h < 8)
      throw new TryOnModelError("Garment placement could not be derived from the pose.");

    // Fit garment box inside the image bounds (shrinks if needed).
    const maxW = imgW * 0.96;
    const maxH = imgH * 0.96;
    if (w > maxW) {
      h = (h * maxW) / w;
      w = maxW;
    }
    if (h > maxH) {
      w = (w * maxH) / h;
      h = maxH;
    }

    const svg = garmentSvg(garment.template, garment.colorHex, w, h);
    let garmentImg = sharp(Buffer.from(svg)).resize(Math.round(w), Math.round(h), {
      fit: "fill",
    });
    const clampedTilt = Math.max(-12, Math.min(12, tiltDeg));
    garmentImg = garmentImg.rotate(clampedTilt, {
      background: { r: 0, g: 0, b: 0, alpha: 0 },
    });
    const gInfo = await garmentImg.png().toBuffer({ resolveWithObject: true });
    const gw = gInfo.info.width;
    const gh = gInfo.info.height;

    const left = Math.max(0, Math.min(imgW - gw, Math.round(x - (gw - w) / 2)));
    const top = Math.max(0, Math.min(imgH - gh, Math.round(y - (gh - h) / 2)));
    if (left < 0 || top < 0)
      throw new TryOnModelError("Garment overlay does not fit within the frame.");

    const out = await sharp(input.image)
      .composite([{ input: gInfo.data, left, top, blend: "over" }])
      .jpeg({ quality: 88 })
      .toBuffer();

    return {
      image: out,
      mime: "image/jpeg",
      meta: { overlayBox: { x: left, y: top, width: gw, height: gh } },
    };
  }
}

/* ------------------------------------------------------------------ */
/* SWAP-IN: hosted / sidecar try-on model.                             */
/* Contract (POST TRYON_API_URL, Bearer TRYON_API_KEY):                */
/*   -> { image_base64, garment: {template,colorHex,name}, size, pose }*/
/*   <- { image_base64 }  (JPEG/PNG composite, same framing)           */
/* ------------------------------------------------------------------ */
export class HttpTryOnModel implements TryOnModel {
  readonly name = "http-remote";

  async tryOn(input: TryOnInput): Promise<TryOnOutput> {
    if (!config.tryonApiUrl)
      throw new TryOnModelError("TRYON_API_URL is not configured.");
    let res: Response;
    try {
      res = await fetch(config.tryonApiUrl, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          authorization: `Bearer ${config.tryonApiKey}`,
        },
        body: JSON.stringify({
          image_base64: input.image.toString("base64"),
          garment: input.garment,
          size: input.size,
          pose: input.pose,
        }),
        signal: AbortSignal.timeout(120_000),
      });
    } catch {
      throw new TryOnModelError("Try-on service is unreachable.");
    }
    if (!res.ok)
      throw new TryOnModelError(`Try-on service failed (HTTP ${res.status}).`);
    const json = (await res.json().catch(() => null)) as {
      image_base64?: string;
    } | null;
    if (!json?.image_base64)
      throw new TryOnModelError("Try-on service returned an invalid payload.");
    const buf = Buffer.from(json.image_base64, "base64");
    return {
      image: buf,
      mime: "image/jpeg",
      meta: { overlayBox: { x: 0, y: 0, width: input.width, height: input.height } },
    };
  }
}

export function getTryOnModel(): TryOnModel {
  return config.tryonProvider === "http"
    ? new HttpTryOnModel()
    : new OverlayTryOnModel();
}
