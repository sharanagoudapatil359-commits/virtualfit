import { ApiError } from "@/lib/api";

/**
 * Simple fixed-window in-memory rate limiter.
 * NOTE: per-process only — for multi-instance production swap this for
 * Redis (INCR + EXPIRE) behind the same function signature.
 */
type Bucket = { count: number; resetAt: number };
const buckets = new Map<string, Bucket>();

export function rateLimit(key: string, limit: number, windowMs: number): void {
  const now = Date.now();
  const b = buckets.get(key);
  if (!b || b.resetAt <= now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return;
  }
  b.count += 1;
  if (b.count > limit) {
    const retrySec = Math.ceil((b.resetAt - now) / 1000);
    throw new ApiError(
      429,
      "RATE_LIMITED",
      `Too many requests. Try again in ${retrySec}s.`,
      { retryAfterSeconds: retrySec },
    );
  }
}

export function clientIp(req: Request): string {
  const fwd = req.headers.get("x-forwarded-for");
  return fwd?.split(",")[0]?.trim() || "local";
}
