import { db } from "@/db";
import { categories, products, productSizes } from "@/db/schema";
import { eq } from "drizzle-orm";
import { ApiError, handler, ok, parseBody } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { productInputSchema } from "@/lib/admin-schema";
import { attachSizes } from "@/lib/catalog";

export const POST = handler(async (req: Request) => {
  await requireAdmin();
  const body = await parseBody(req, productInputSchema);
  const [cat] = await db
    .select()
    .from(categories)
    .where(eq(categories.id, body.categoryId))
    .limit(1);
  if (!cat) throw new ApiError(400, "CATEGORY_NOT_FOUND", "Unknown category.");

  const created = await db.transaction(async (tx) => {
    const [p] = await tx
      .insert(products)
      .values({
        name: body.name,
        categoryId: body.categoryId,
        description: body.description,
        colorHex: body.colorHex,
        garmentTemplate: body.garmentTemplate,
        priceCents: body.priceCents,
      })
      .returning();
    await tx
      .insert(productSizes)
      .values(body.sizes.map((s) => ({ productId: p.id, size: s.size, stock: s.stock })));
    return p;
  });
  const [dto] = await attachSizes([{ p: created, c: cat }]);
  return ok({ product: dto }, 201);
});
