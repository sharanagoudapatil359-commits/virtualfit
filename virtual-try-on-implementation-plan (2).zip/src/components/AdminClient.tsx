"use client";

import { useCallback, useEffect, useState } from "react";
import { Loader2, Package, Plus, ReceiptText, Users } from "lucide-react";
import type { ProductDto } from "@/lib/catalog";
import { GARMENT_TEMPLATES, SIZES, money } from "@/lib/constants";
import { useToast } from "@/components/Toast";

interface AdminOrder {
  id: string; status: string; totalCents: number; createdAt: string;
  customer: { name: string; email: string };
  items: { name: string; size: string; qty: number; unitPriceCents: number }[];
}
interface AdminUser { id: string; name: string; email: string; role: "user" | "admin" }

type Tab = "products" | "orders" | "users";

export default function AdminClient({
  categories,
}: {
  categories: { id: string; name: string; slug: string }[];
}) {
  const { push } = useToast();
  const [tab, setTab] = useState<Tab>("products");
  const [products, setProducts] = useState<ProductDto[]>([]);
  const [orders, setOrders] = useState<AdminOrder[]>([]);
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  // create form
  const [f, setF] = useState({
    name: "", categoryId: categories[0]?.id ?? "", description: "",
    colorHex: "#8B7CFF", garmentTemplate: "tee", price: "49",
  });
  const [stock, setStock] = useState<Record<string, number>>(
    Object.fromEntries(SIZES.map((s) => [s, 5])),
  );

  const load = useCallback(async () => {
    setLoading(true);
    const [p, o, u] = await Promise.all([
      fetch("/api/products", { cache: "no-store" }),
      fetch("/api/admin/orders", { cache: "no-store" }),
      fetch("/api/admin/users", { cache: "no-store" }),
    ]);
    if (p.ok) setProducts((await p.json()).data.products);
    if (o.ok) setOrders((await o.json()).data.orders);
    if (u.ok) setUsers((await u.json()).data.users);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const createProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    const res = await fetch("/api/admin/products", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        name: f.name,
        categoryId: f.categoryId,
        description: f.description,
        colorHex: f.colorHex,
        garmentTemplate: f.garmentTemplate,
        priceCents: Math.round(parseFloat(f.price || "0") * 100),
        sizes: SIZES.map((size) => ({ size, stock: stock[size] ?? 0 })),
      }),
    });
    setSaving(false);
    const j = await res.json().catch(() => null);
    if (!res.ok) return push(j?.error?.message ?? "Create failed.", "error");
    push(`"${j.data.product.name}" created.`, "success");
    setF({ ...f, name: "", description: "" });
    load();
  };

  const saveStock = async (p: ProductDto) => {
    const res = await fetch(`/api/admin/products/${p.id}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ sizes: p.sizes.map((s) => ({ size: s.size, stock: s.stock })) }),
    });
    if (res.ok) push(`Stock updated for ${p.name}.`, "success");
    else push("Stock update failed.", "error");
  };

  const setRole = async (u: AdminUser, role: "user" | "admin") => {
    const res = await fetch(`/api/admin/users/${u.id}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ role }),
    });
    const j = await res.json().catch(() => null);
    if (!res.ok) return push(j?.error?.message ?? "Role change failed.", "error");
    push(`${u.email} is now ${role}.`, "success");
    load();
  };

  const tabBtn = (t: Tab, label: string, Icon: typeof Package) => (
    <button
      onClick={() => setTab(t)}
      className={`inline-flex items-center gap-2 rounded-full border px-4 py-2 text-xs font-bold uppercase tracking-[0.1em] transition ${
        tab === t ? "border-lime bg-lime text-ink" : "border-white/12 text-cream/60 hover:text-cream"
      }`}
    >
      <Icon size={13} /> {label}
    </button>
  );

  return (
    <div className="mx-auto max-w-6xl px-5 py-12">
      <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.24em] text-violet">Admin</p>
      <h1 className="font-display text-3xl font-extrabold">Control room</h1>
      <div className="mt-6 flex gap-2">
        {tabBtn("products", "Products", Package)}
        {tabBtn("orders", "Orders", ReceiptText)}
        {tabBtn("users", "Users", Users)}
      </div>

      {loading ? (
        <div className="mt-16 flex justify-center"><Loader2 className="animate-spin text-lime" /></div>
      ) : tab === "products" ? (
        <div className="mt-8 grid gap-8 lg:grid-cols-[360px_1fr]">
          <form onSubmit={createProduct} className="h-fit space-y-3 rounded-3xl border border-white/8 bg-panel p-5">
            <h2 className="mb-1 flex items-center gap-2 text-sm font-bold uppercase tracking-[0.12em]">
              <Plus size={14} className="text-lime" /> New product
            </h2>
            <input className="input" placeholder="Name" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} required />
            <select className="input" value={f.categoryId} onChange={(e) => setF({ ...f, categoryId: e.target.value })}>
              {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
            <select className="input" value={f.garmentTemplate} onChange={(e) => setF({ ...f, garmentTemplate: e.target.value })}>
              {GARMENT_TEMPLATES.map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
            <div className="flex gap-3">
              <label className="flex flex-1 items-center gap-2 rounded-xl border border-white/10 px-3 py-2 text-sm">
                <input type="color" value={f.colorHex} onChange={(e) => setF({ ...f, colorHex: e.target.value })} className="h-7 w-9 cursor-pointer rounded bg-transparent" />
                <span className="font-mono text-xs text-mute">{f.colorHex}</span>
              </label>
              <input className="input w-28" placeholder="Price $" value={f.price} onChange={(e) => setF({ ...f, price: e.target.value })} inputMode="decimal" />
            </div>
            <textarea className="input min-h-20" placeholder="Description" value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} />
            <div className="grid grid-cols-6 gap-1.5">
              {SIZES.map((s) => (
                <label key={s} className="text-center">
                  <span className="text-[10px] font-bold text-mute">{s}</span>
                  <input
                    className="input mt-1 px-1 text-center text-xs"
                    type="number"
                    min={0}
                    value={stock[s]}
                    onChange={(e) => setStock({ ...stock, [s]: Number(e.target.value) })}
                  />
                </label>
              ))}
            </div>
            <button disabled={saving} className="w-full rounded-full bg-lime py-2.5 text-xs font-black uppercase tracking-[0.1em] text-ink transition hover:bg-cream disabled:opacity-50">
              {saving ? "Saving…" : "Create product"}
            </button>
          </form>

          <div className="space-y-2">
            {products.map((p) => (
              <div key={p.id} className="flex flex-wrap items-center gap-3 rounded-2xl border border-white/8 bg-panel p-3.5">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={p.imageUrl} alt="" className="h-12 w-12 rounded-xl object-contain" style={{ background: `${p.colorHex}22` }} />
                <div className="min-w-28 flex-1">
                  <p className="truncate text-sm font-semibold">{p.name}</p>
                  <p className="text-xs text-mute">{p.category?.name} · {money(p.priceCents)}</p>
                </div>
                <div className="flex items-center gap-1.5">
                  {p.sizes.map((s) => (
                    <label key={s.size} className="text-center">
                      <span className="block text-[9px] font-bold text-mute">{s.size}</span>
                      <input
                        type="number"
                        min={0}
                        value={s.stock}
                        onChange={(e) =>
                          setProducts((ps) =>
                            ps.map((x) =>
                              x.id === p.id
                                ? { ...x, sizes: x.sizes.map((y) => (y.size === s.size ? { ...y, stock: Number(e.target.value) } : y)) }
                                : x,
                            ),
                          )
                        }
                        className="w-12 rounded-md border border-white/12 bg-ink px-1 py-1 text-center text-xs"
                      />
                    </label>
                  ))}
                  <button onClick={() => saveStock(p)} className="ml-1 rounded-full border border-lime/50 px-3 py-1.5 text-[10px] font-bold uppercase text-lime hover:bg-lime/10">
                    Save
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : tab === "orders" ? (
        <div className="mt-8 space-y-2">
          {orders.length === 0 && <p className="text-sm text-mute">No orders yet.</p>}
          {orders.map((o) => (
            <div key={o.id} className="rounded-2xl border border-white/8 bg-panel p-4">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="text-sm font-semibold">
                  <span className="font-mono text-cream/60">#{o.id.slice(0, 8)}</span> · {o.customer.name}
                  <span className="ml-2 text-xs text-mute">{o.customer.email}</span>
                </p>
                <p className="text-sm">
                  <span className="mr-3 rounded-full border border-lime/40 px-2 py-0.5 text-[10px] font-bold uppercase text-lime">{o.status}</span>
                  <span className="font-bold text-lime">{money(o.totalCents)}</span>
                </p>
              </div>
              <p className="mt-1.5 text-xs text-mute">
                {o.items.map((i) => `${i.name} (${i.size}) ×${i.qty}`).join(" · ")} — {new Date(o.createdAt).toLocaleString()}
              </p>
            </div>
          ))}
        </div>
      ) : (
        <div className="mt-8 space-y-2">
          {users.map((u) => (
            <div key={u.id} className="flex items-center justify-between gap-3 rounded-2xl border border-white/8 bg-panel p-4">
              <div>
                <p className="text-sm font-semibold">{u.name}</p>
                <p className="text-xs text-mute">{u.email}</p>
              </div>
              <button
                onClick={() => setRole(u, u.role === "admin" ? "user" : "admin")}
                className={`rounded-full border px-3.5 py-1.5 text-[10px] font-bold uppercase tracking-[0.1em] transition ${
                  u.role === "admin" ? "border-lime/50 text-lime hover:bg-lime/10" : "border-white/15 text-mute hover:border-lime/40 hover:text-lime"
                }`}
              >
                {u.role === "admin" ? "Admin — demote" : "Make admin"}
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
