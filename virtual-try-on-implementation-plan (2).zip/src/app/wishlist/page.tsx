"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { ArrowRight, Heart, Loader2, ScanFace, Trash2 } from "lucide-react";
import { money } from "@/lib/constants";
import { useToast } from "@/components/Toast";

interface WishItem {
  id: string; productId: string; name: string; colorHex: string;
  imageUrl: string; priceCents: number; addedAt: string;
}

export default function WishlistPage() {
  const { push } = useToast();
  const [items, setItems] = useState<WishItem[] | null>(null);
  const [authed, setAuthed] = useState(true);

  const load = useCallback(async () => {
    const res = await fetch("/api/wishlist", { cache: "no-store" });
    if (res.status === 401) { setAuthed(false); return; }
    const j = await res.json();
    setItems(j.data.items);
  }, []);

  useEffect(() => { load(); }, [load]);

  const remove = async (productId: string) => {
    const res = await fetch("/api/wishlist", {
      method: "DELETE",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ productId }),
    });
    if (res.ok) {
      setItems((xs) => xs?.filter((i) => i.productId !== productId) ?? []);
      push("Removed from wishlist.", "info");
    }
  };

  if (!authed)
    return (
      <div className="mx-auto max-w-md px-5 py-24 text-center">
        <Heart size={28} className="mx-auto text-cream/20" />
        <h1 className="mt-4 font-display text-2xl font-bold">Your wishlist lives here</h1>
        <p className="mt-2 text-sm text-mute">Sign in to save and revisit pieces.</p>
        <Link href="/login?next=/wishlist" className="mt-6 inline-flex items-center gap-2 rounded-full bg-lime px-6 py-3 text-sm font-bold text-ink hover:bg-cream">
          Sign in <ArrowRight size={15} />
        </Link>
      </div>
    );

  return (
    <div className="mx-auto max-w-5xl px-5 py-12">
      <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.24em] text-violet">Wishlist</p>
      <h1 className="font-display text-3xl font-extrabold">Saved for later</h1>

      {items === null ? (
        <div className="mt-16 flex justify-center"><Loader2 className="animate-spin text-lime" /></div>
      ) : items.length === 0 ? (
        <div className="mt-10 rounded-3xl border border-dashed border-white/15 p-16 text-center">
          <Heart size={26} className="mx-auto text-cream/20" />
          <p className="mt-4 font-display text-lg">No saves yet.</p>
          <Link href="/catalog" className="mt-4 inline-block text-sm text-lime hover:underline">
            Find something to love →
          </Link>
        </div>
      ) : (
        <div className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
          {items.map((it) => (
            <div key={it.id} className="overflow-hidden rounded-3xl border border-white/8 bg-panel">
              <div className="relative aspect-square" style={{ background: `${it.colorHex}22` }}>
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img src={it.imageUrl} alt={it.name} className="h-full w-full object-contain p-6" />
                <button
                  onClick={() => remove(it.productId)}
                  className="absolute right-3 top-3 grid h-8 w-8 place-items-center rounded-full border border-white/10 bg-ink/60 text-cream/60 backdrop-blur transition hover:text-ember"
                  aria-label="Remove from wishlist"
                >
                  <Trash2 size={13} />
                </button>
              </div>
              <div className="p-4">
                <p className="truncate text-sm font-semibold">{it.name}</p>
                <p className="mt-0.5 text-xs text-lime">{money(it.priceCents)}</p>
                <Link
                  href={`/tryon?product=${it.productId}`}
                  className="mt-3 flex items-center justify-center gap-1.5 rounded-full border border-violet/50 py-2 text-[11px] font-bold uppercase tracking-[0.1em] text-violet transition hover:bg-violet/15"
                >
                  <ScanFace size={12} /> Try it on
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
