"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import {
  Aperture,
  Heart,
  LogOut,
  Menu,
  ShieldCheck,
  ShoppingBag,
  Store,
  X,
} from "lucide-react";
import { useToast } from "@/components/Toast";

interface Me { id: string; name: string; email: string; role: "user" | "admin" }

export default function Navbar() {
  const pathname = usePathname();
  const router = useRouter();
  const { push } = useToast();
  const [me, setMe] = useState<Me | null>(null);
  const [cartCount, setCartCount] = useState(0);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    setOpen(false);
    (async () => {
      const res = await fetch("/api/auth/me", { cache: "no-store" });
      if (res.ok) {
        const { data } = await res.json();
        setMe(data.user);
        const cart = await fetch("/api/cart", { cache: "no-store" });
        if (cart.ok) {
          const j = await cart.json();
          setCartCount(j.data.items.reduce((s: number, i: { qty: number }) => s + i.qty, 0));
        }
      } else {
        setMe(null);
        setCartCount(0);
      }
    })();
  }, [pathname]);

  const logout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    setMe(null);
    push("Signed out. See you soon.", "success");
    router.refresh();
    router.push("/");
  };

  const linkCls = (href: string) =>
    `text-[13px] font-medium uppercase tracking-[0.14em] transition-colors ${
      pathname.startsWith(href) ? "text-lime" : "text-cream/60 hover:text-cream"
    }`;

  return (
    <header className="sticky top-0 z-50 border-b border-white/5 bg-ink/75 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5">
        <Link href="/" className="flex items-center gap-2.5">
          <span className="grid h-8 w-8 place-items-center rounded-lg bg-lime text-ink">
            <Aperture size={17} strokeWidth={2.4} />
          </span>
          <span className="font-display text-[15px] font-semibold tracking-wide">
            VIRTUAL<span className="text-lime">FIT</span>
          </span>
        </Link>

        <nav className="hidden items-center gap-8 md:flex">
          <Link href="/catalog" className={linkCls("/catalog")}>
            <span className="inline-flex items-center gap-1.5"><Store size={14} /> Catalog</span>
          </Link>
          <Link href="/tryon" className={linkCls("/tryon")}>
            <span className="inline-flex items-center gap-1.5"><Aperture size={14} /> Studio</span>
          </Link>
          <Link href="/wishlist" className={linkCls("/wishlist")}>
            <span className="inline-flex items-center gap-1.5"><Heart size={14} /> Wishlist</span>
          </Link>
          <Link href="/cart" className={`relative ${linkCls("/cart")}`}>
            <span className="inline-flex items-center gap-1.5">
              <ShoppingBag size={14} /> Cart
              {cartCount > 0 && (
                <span className="rounded-full bg-lime px-1.5 py-0.5 text-[10px] font-bold leading-none text-ink">
                  {cartCount}
                </span>
              )}
            </span>
          </Link>
          {me?.role === "admin" && (
            <Link href="/admin" className={linkCls("/admin")}>
              <span className="inline-flex items-center gap-1.5"><ShieldCheck size={14} /> Admin</span>
            </Link>
          )}
        </nav>

        <div className="hidden items-center gap-3 md:flex">
          {me ? (
            <>
              <span className="max-w-[160px] truncate rounded-full border border-white/10 px-3.5 py-1.5 text-xs text-cream/70">
                {me.name}
              </span>
              <button
                onClick={logout}
                className="grid h-9 w-9 place-items-center rounded-full border border-white/10 text-cream/60 transition hover:border-ember/60 hover:text-ember"
                title="Sign out"
                aria-label="Sign out"
              >
                <LogOut size={15} />
              </button>
            </>
          ) : (
            <>
              <Link href="/login" className="text-[13px] font-medium uppercase tracking-[0.14em] text-cream/60 hover:text-cream">
                Sign in
              </Link>
              <Link
                href="/register"
                className="rounded-full bg-cream px-4.5 py-2 text-[13px] font-semibold uppercase tracking-[0.1em] text-ink transition hover:bg-lime"
              >
                Join
              </Link>
            </>
          )}
        </div>

        <button
          className="grid h-9 w-9 place-items-center rounded-lg border border-white/10 md:hidden"
          onClick={() => setOpen((v) => !v)}
          aria-label="Menu"
        >
          {open ? <X size={17} /> : <Menu size={17} />}
        </button>
      </div>

      {open && (
        <nav className="flex flex-col gap-1 border-t border-white/5 bg-ink px-5 py-4 md:hidden">
          {[
            ["/catalog", "Catalog"],
            ["/tryon", "Studio"],
            ["/wishlist", "Wishlist"],
            ["/cart", `Cart${cartCount ? ` (${cartCount})` : ""}`],
            ...(me?.role === "admin" ? [["/admin", "Admin"]] : []),
            ...(me ? [] : [["/login", "Sign in"], ["/register", "Create account"]]),
          ].map(([href, label]) => (
            <Link
              key={href as string}
              href={href as string}
              className="rounded-lg px-3 py-2.5 text-sm text-cream/80 hover:bg-white/5"
            >
              {label as string}
            </Link>
          ))}
          {me && (
            <button onClick={logout} className="rounded-lg px-3 py-2.5 text-left text-sm text-ember">
              Sign out ({me.email})
            </button>
          )}
        </nav>
      )}
    </header>
  );
}
