import "dotenv/config";
import { and, eq, gte, sql } from "drizzle-orm";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { db } from "@/db";
import {
  cartItems,
  categories,
  products,
  productSizes,
  users,
  wishlistItems,
} from "@/db/schema";
import { getCart } from "@/lib/cart";
import { computeTotals } from "@/lib/orders";

/**
 * Integration: cart + wishlist + stock reservation against a real DB.
 * Skipped automatically when DATABASE_URL is absent.
 */
describe.skipIf(!process.env.DATABASE_URL)("cart flow (DB integration)", () => {
  let userId = "";
  let productId = "";
  let catId = "";

  beforeAll(async () => {
    const [u] = await db
      .insert(users)
      .values({ name: "Test Runner", email: `test-${Date.now()}@example.dev`, passwordHash: "x" })
      .returning();
    userId = u.id;
    const [c] = await db
      .insert(categories)
      .values({ slug: `test-${Date.now()}`, name: "Test" })
      .returning();
    catId = c.id;
    const [p] = await db
      .insert(products)
      .values({
        categoryId: catId,
        name: "Test Tee",
        colorHex: "#4c6fff",
        garmentTemplate: "tee",
        priceCents: 2500,
      })
      .returning();
    productId = p.id;
    await db.insert(productSizes).values({ productId, size: "M", stock: 3 });
  });

  afterAll(async () => {
    if (userId) await db.delete(users).where(eq(users.id, userId)); // cascades cart/wishlist
    if (productId) await db.delete(products).where(eq(products.id, productId));
    if (catId) await db.delete(categories).where(eq(categories.id, catId));
  });

  it("adds an item, computes totals, and respects the unique (user,product,size)", async () => {
    await db.insert(cartItems).values({ userId, productId, size: "M", qty: 2 });
    // duplicate insert must fail (unique index)
    await expect(
      db.insert(cartItems).values({ userId, productId, size: "M", qty: 1 }),
    ).rejects.toThrow();

    const cart = await getCart(userId);
    expect(cart.items).toHaveLength(1);
    expect(cart.items[0].qty).toBe(2);
    expect(cart.items[0].unitPriceCents).toBe(2500);
    expect(cart.totals).toEqual(computeTotals([{ unitPriceCents: 2500, qty: 2 }]));
  });

  it("wishlist ignores duplicates via onConflictDoNothing", async () => {
    await db.insert(wishlistItems).values({ userId, productId });
    const again = await db
      .insert(wishlistItems)
      .values({ userId, productId })
      .onConflictDoNothing()
      .returning();
    expect(again).toHaveLength(0);
  });

  it("conditional stock decrement succeeds only when enough stock", async () => {
    // 2 of 3 in stock → ok
    const okRows = await db
      .update(productSizes)
      .set({ stock: sql`${productSizes.stock} - 2` })
      .where(
        and(
          eq(productSizes.productId, productId),
          eq(productSizes.size, "M"),
          gte(productSizes.stock, 2),
        ),
      )
      .returning();
    expect(okRows).toHaveLength(1);
    expect(okRows[0].stock).toBe(1);

    // asking for 5 with 1 left → no rows updated (checkout would 409)
    const failRows = await db
      .update(productSizes)
      .set({ stock: sql`${productSizes.stock} - 5` })
      .where(
        and(
          eq(productSizes.productId, productId),
          eq(productSizes.size, "M"),
          gte(productSizes.stock, 5),
        ),
      )
      .returning();
    expect(failRows).toHaveLength(0);
  });
});
