import { Sparkles } from "lucide-react";
import TryOnStudio from "@/components/TryOnStudio";
import Reveal from "@/components/Reveal";

export const metadata = { title: "Try-On Studio — Virtual Fit" };

export default async function TryOnPage({
  searchParams,
}: {
  searchParams: Promise<{ product?: string }>;
}) {
  const { product } = await searchParams;
  return (
    <div className="mx-auto max-w-7xl px-5 py-12">
      <Reveal>
        <p className="mb-2 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.24em] text-violet">
          <Sparkles size={12} /> Try-On Studio
        </p>
        <h1 className="font-display text-3xl font-extrabold md:text-4xl">
          See it on <span className="text-lime">your</span> frame.
        </h1>
        <p className="mt-3 max-w-lg text-sm text-mute">
          Three steps: your photo, a garment, a render. Our pose pipeline maps
          the piece to your shoulders and hips, scaled by size.
        </p>
      </Reveal>
      <div className="mt-10">
        <TryOnStudio preselect={product} />
      </div>
    </div>
  );
}
