import AuthForm from "@/components/AuthForm";

export const metadata = { title: "Create account — Virtual Fit" };

export default function RegisterPage() {
  return <AuthForm mode="register" />;
}
