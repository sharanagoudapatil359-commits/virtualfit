import {
  pgTable,
  pgEnum,
  uuid,
  text,
  integer,
  boolean,
  timestamp,
  jsonb,
  primaryKey,
  uniqueIndex,
  index,
} from "drizzle-orm/pg-core";

/* ------------------------------------------------------------------ */
/* Enums                                                               */
/* ------------------------------------------------------------------ */
export const userRoleEnum = pgEnum("user_role", ["user", "admin"]);
export const tryonStatusEnum = pgEnum("tryon_status", [
  "queued",
  "processing",
  "completed",
  "failed",
]);
export const orderStatusEnum = pgEnum("order_status", [
  "placed",
  "paid",
  "shipped",
  "cancelled",
]);

/* ------------------------------------------------------------------ */
/* 1. User module                                                      */
/* ------------------------------------------------------------------ */
export const users = pgTable(
  "users",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    name: text("name").notNull(),
    email: text("email").notNull(), // stored lowercased, unique
    passwordHash: text("password_hash").notNull(),
    role: userRoleEnum("role").default("user").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (t) => [uniqueIndex("users_email_unique").on(t.email)],
);

export const sessions = pgTable(
  "sessions",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id")
      .references(() => users.id, { onDelete: "cascade" })
      .notNull(),
    tokenHash: text("token_hash").notNull(), // sha256 of opaque cookie token
    expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (t) => [
    uniqueIndex("sessions_token_unique").on(t.tokenHash),
    index("sessions_user_idx").on(t.userId),
  ],
);

/* ------------------------------------------------------------------ */
/* 3. Product module                                                   */
/* ------------------------------------------------------------------ */
export const categories = pgTable("categories", {
  id: uuid("id").defaultRandom().primaryKey(),
  slug: text("slug").notNull(),
  name: text("name").notNull(),
  sortOrder: integer("sort_order").default(0).notNull(),
});

export const products = pgTable(
  "products",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    categoryId: uuid("category_id")
      .references(() => categories.id)
      .notNull(),
    name: text("name").notNull(),
    description: text("description").default("").notNull(),
    colorHex: text("color_hex").notNull(), // garment tint, e.g. "#4C6FFF"
    // garment silhouette used by the try-on renderer
    garmentTemplate: text("garment_template").notNull(), // tee|dress|pants|skirt|jacket
    priceCents: integer("price_cents").notNull(),
    active: boolean("active").default(true).notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (t) => [index("products_category_idx").on(t.categoryId)],
);

// Per-size stock; PK (product_id, size)
export const productSizes = pgTable(
  "product_sizes",
  {
    productId: uuid("product_id")
      .references(() => products.id, { onDelete: "cascade" })
      .notNull(),
    size: text("size").notNull(), // XS|S|M|L|XL|XXL
    stock: integer("stock").default(0).notNull(),
  },
  (t) => [primaryKey({ columns: [t.productId, t.size] })],
);

/* ------------------------------------------------------------------ */
/* 4. Image upload module                                              */
/* ------------------------------------------------------------------ */
export const uploads = pgTable(
  "uploads",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id")
      .references(() => users.id, { onDelete: "cascade" })
      .notNull(),
    fileName: text("file_name").notNull(), // random, stored outside web root
    mime: text("mime").notNull(),
    width: integer("width").notNull(),
    height: integer("height").notNull(),
    bytes: integer("bytes").notNull(),
    sha256: text("sha256").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (t) => [
    uniqueIndex("uploads_file_unique").on(t.fileName),
    index("uploads_user_idx").on(t.userId),
  ],
);

/* ------------------------------------------------------------------ */
/* 5. Virtual try-on module (job-based; sync for the overlay model,    */
/*    async-ready for a real generative model worker)                  */
/* ------------------------------------------------------------------ */
export const tryonJobs = pgTable(
  "tryon_jobs",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id")
      .references(() => users.id, { onDelete: "cascade" })
      .notNull(),
    uploadId: uuid("upload_id")
      .references(() => uploads.id, { onDelete: "cascade" })
      .notNull(),
    productId: uuid("product_id")
      .references(() => products.id)
      .notNull(),
    size: text("size").notNull(),
    status: tryonStatusEnum("status").default("queued").notNull(),
    errorCode: text("error_code"),
    errorMessage: text("error_message"),
    resultFile: text("result_file"), // r_<jobId>.jpg under <UPLOAD_DIR>/results
    landmarks: jsonb("landmarks"), // detected pose keypoints (pixels)
    warnings: jsonb("warnings"), // e.g. ["NON_FRONTAL_POSE"]
    processingMs: integer("processing_ms"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (t) => [index("tryon_jobs_user_idx").on(t.userId, t.createdAt)],
);

/* ------------------------------------------------------------------ */
/* 6. Cart / wishlist / orders                                         */
/* ------------------------------------------------------------------ */
export const cartItems = pgTable(
  "cart_items",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id")
      .references(() => users.id, { onDelete: "cascade" })
      .notNull(),
    productId: uuid("product_id")
      .references(() => products.id, { onDelete: "cascade" })
      .notNull(),
    size: text("size").notNull(),
    qty: integer("qty").notNull(),
    addedAt: timestamp("added_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (t) => [
    uniqueIndex("cart_unique_item").on(t.userId, t.productId, t.size),
    index("cart_user_idx").on(t.userId),
  ],
);

export const wishlistItems = pgTable(
  "wishlist_items",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id")
      .references(() => users.id, { onDelete: "cascade" })
      .notNull(),
    productId: uuid("product_id")
      .references(() => products.id, { onDelete: "cascade" })
      .notNull(),
    addedAt: timestamp("added_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (t) => [uniqueIndex("wishlist_unique_item").on(t.userId, t.productId)],
);

export const orders = pgTable(
  "orders",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    userId: uuid("user_id")
      .references(() => users.id)
      .notNull(),
    status: orderStatusEnum("status").default("placed").notNull(),
    subtotalCents: integer("subtotal_cents").notNull(),
    shippingCents: integer("shipping_cents").notNull(),
    taxCents: integer("tax_cents").notNull(),
    totalCents: integer("total_cents").notNull(),
    createdAt: timestamp("created_at", { withTimezone: true })
      .defaultNow()
      .notNull(),
  },
  (t) => [index("orders_user_idx").on(t.userId)],
);

export const orderItems = pgTable(
  "order_items",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    orderId: uuid("order_id")
      .references(() => orders.id, { onDelete: "cascade" })
      .notNull(),
    productId: uuid("product_id")
      .references(() => products.id)
      .notNull(),
    size: text("size").notNull(),
    qty: integer("qty").notNull(),
    unitPriceCents: integer("unit_price_cents").notNull(),
  },
  (t) => [index("order_items_order_idx").on(t.orderId)],
);

/* ------------------------------------------------------------------ */
/* Inferred types                                                      */
/* ------------------------------------------------------------------ */
export type User = typeof users.$inferSelect;
export type Session = typeof sessions.$inferSelect;
export type Product = typeof products.$inferSelect;
export type Category = typeof categories.$inferSelect;
export type Upload = typeof uploads.$inferSelect;
export type TryonJob = typeof tryonJobs.$inferSelect;
export type CartItem = typeof cartItems.$inferSelect;
export type Order = typeof orders.$inferSelect;
