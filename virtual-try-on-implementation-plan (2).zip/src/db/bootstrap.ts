import { pool } from "./index";

/**
 * Self-bootstrap: guarantees the schema + demo data exist in ANY fresh
 * environment (preview boxes included) without needing `drizzle-kit push`.
 * Fully idempotent: every DDL uses IF NOT EXISTS, guarded by pg advisory
 * lock inside ensureSeed(). Drift-controlled because it mirrors
 * src/db/schema.ts 1:1 — keep both in sync.
 */

const DDL = `
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'user_role')
    THEN CREATE TYPE user_role AS ENUM ('user', 'admin'); END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'tryon_status')
    THEN CREATE TYPE tryon_status AS ENUM ('queued', 'processing', 'completed', 'failed'); END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'order_status')
    THEN CREATE TYPE order_status AS ENUM ('placed', 'paid', 'shipped', 'cancelled'); END IF;
END $$;

CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  email text NOT NULL,
  password_hash text NOT NULL,
  role user_role NOT NULL DEFAULT 'user',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS users_email_unique ON users (email);

CREATE TABLE IF NOT EXISTS sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE cascade,
  token_hash text NOT NULL,
  expires_at timestamptz NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS sessions_token_unique ON sessions (token_hash);
CREATE INDEX IF NOT EXISTS sessions_user_idx ON sessions (user_id);

CREATE TABLE IF NOT EXISTS categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL,
  name text NOT NULL,
  sort_order integer NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id uuid NOT NULL REFERENCES categories(id),
  name text NOT NULL,
  description text NOT NULL DEFAULT '',
  color_hex text NOT NULL,
  garment_template text NOT NULL,
  price_cents integer NOT NULL,
  active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS products_category_idx ON products (category_id);

CREATE TABLE IF NOT EXISTS product_sizes (
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE cascade,
  size text NOT NULL,
  stock integer NOT NULL DEFAULT 0,
  PRIMARY KEY (product_id, size)
);

CREATE TABLE IF NOT EXISTS uploads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE cascade,
  file_name text NOT NULL,
  mime text NOT NULL,
  width integer NOT NULL,
  height integer NOT NULL,
  bytes integer NOT NULL,
  sha256 text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS uploads_file_unique ON uploads (file_name);
CREATE INDEX IF NOT EXISTS uploads_user_idx ON uploads (user_id);

CREATE TABLE IF NOT EXISTS tryon_jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE cascade,
  upload_id uuid NOT NULL REFERENCES uploads(id) ON DELETE cascade,
  product_id uuid NOT NULL REFERENCES products(id),
  size text NOT NULL,
  status tryon_status NOT NULL DEFAULT 'queued',
  error_code text,
  error_message text,
  result_file text,
  landmarks jsonb,
  warnings jsonb,
  processing_ms integer,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS tryon_jobs_user_idx ON tryon_jobs (user_id, created_at);

CREATE TABLE IF NOT EXISTS cart_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE cascade,
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE cascade,
  size text NOT NULL,
  qty integer NOT NULL,
  added_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS cart_unique_item ON cart_items (user_id, product_id, size);
CREATE INDEX IF NOT EXISTS cart_user_idx ON cart_items (user_id);

CREATE TABLE IF NOT EXISTS wishlist_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE cascade,
  product_id uuid NOT NULL REFERENCES products(id) ON DELETE cascade,
  added_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS wishlist_unique_item ON wishlist_items (user_id, product_id);

CREATE TABLE IF NOT EXISTS orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES users(id),
  status order_status NOT NULL DEFAULT 'placed',
  subtotal_cents integer NOT NULL,
  shipping_cents integer NOT NULL,
  tax_cents integer NOT NULL,
  total_cents integer NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS orders_user_idx ON orders (user_id);

CREATE TABLE IF NOT EXISTS order_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id uuid NOT NULL REFERENCES orders(id) ON DELETE cascade,
  product_id uuid NOT NULL REFERENCES products(id),
  size text NOT NULL,
  qty integer NOT NULL,
  unit_price_cents integer NOT NULL
);
CREATE INDEX IF NOT EXISTS order_items_order_idx ON order_items (order_id);
`;

let bootstrapped = false;

export async function bootstrapDatabase(): Promise<void> {
  if (bootstrapped) return;
  // node-postgres simple-query protocol supports multi-statement SQL
  // (the DO $$ blocks and inner semicolons are parsed server-side).
  await pool.query(DDL);
  const { ensureSeed } = await import("./seed");
  await ensureSeed();
  bootstrapped = true; // only after success, so a failed boot retries next time
}
