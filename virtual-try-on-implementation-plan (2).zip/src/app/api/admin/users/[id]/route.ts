import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { users } from "@/db/schema";
import { ApiError, handler, ok, parseBody } from "@/lib/api";
import { publicUser, requireAdmin } from "@/lib/auth";

type Ctx = { params: Promise<{ id: string }> };

const schema = z.object({ role: z.enum(["user", "admin"]) });

/** PATCH /api/admin/users/:id — change a user's role. */
export const PATCH = handler(async (req: Request, ctx: Ctx) => {
  const admin = await requireAdmin();
  const { id } = await ctx.params;
  const { role } = await parseBody(req, schema);
  if (admin.id === id && role !== "admin")
    throw new ApiError(400, "SELF_DEMOTE", "You cannot remove your own admin role.");
  const [updated] = await db
    .update(users)
    .set({ role })
    .where(eq(users.id, id))
    .returning();
  if (!updated) throw new ApiError(404, "USER_NOT_FOUND", "User not found.");
  return ok({ user: publicUser(updated) });
});
