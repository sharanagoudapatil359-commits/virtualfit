import { createHash, randomUUID } from "crypto";
import { mkdir, readFile, unlink, writeFile } from "fs/promises";
import path from "path";
import sharp from "sharp";
import { config, resultsDir } from "@/lib/config";
import { ApiError } from "@/lib/api";

/**
 * Image upload module: magic-byte sniffing, size/dimension limits,
 * EXIF stripping + re-encode (kills embedded metadata & polyglot tricks),
 * random filenames, storage OUTSIDE the web root.
 */

const SAFE_NAME = /^[a-z0-9._-]+$/i;

export function sniffMime(buf: Buffer): string | null {
  if (buf.length > 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff)
    return "image/jpeg";
  if (
    buf.length > 8 &&
    buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47
  )
    return "image/png";
  if (
    buf.length > 12 &&
    buf.toString("ascii", 0, 4) === "RIFF" &&
    buf.toString("ascii", 8, 12) === "WEBP"
  )
    return "image/webp";
  return null;
}

export async function ensureDirs(): Promise<void> {
  await mkdir(resultsDir(), { recursive: true });
}

export interface StoredPhoto {
  fileName: string;
  width: number;
  height: number;
  bytes: number;
  sha256: string;
}

/** Validate + normalize a user photo, then persist it. Throws ApiError. */
export async function saveUserPhoto(raw: Buffer): Promise<StoredPhoto> {
  if (!raw || raw.length === 0)
    throw new ApiError(400, "EMPTY_FILE", "No file was received.");
  if (raw.length > config.maxUploadBytes)
    throw new ApiError(
      413,
      "FILE_TOO_LARGE",
      `Photo exceeds the ${Math.round(config.maxUploadBytes / 1024 / 1024)}MB limit.`,
    );
  const mime = sniffMime(raw);
  if (!mime)
    throw new ApiError(
      415,
      "UNSUPPORTED_MEDIA_TYPE",
      "Only JPEG, PNG or WebP photos are supported.",
    );

  let img = sharp(raw, { failOn: "error" }).rotate(); // auto-orient + strip EXIF
  let out;
  try {
    out = await img
      .resize({
        width: config.maxImageDim,
        height: config.maxImageDim,
        fit: "inside",
        withoutEnlargement: true,
      })
      .jpeg({ quality: 88 })
      .toBuffer({ resolveWithObject: true });
  } catch {
    throw new ApiError(
      422,
      "MALFORMED_IMAGE",
      "The file could not be decoded as an image.",
    );
  }
  const { width, height } = out.info;
  if (width < config.minImageWidth || height < config.minImageHeight)
    throw new ApiError(
      422,
      "IMAGE_TOO_SMALL",
      `Photo must be at least ${config.minImageWidth}x${config.minImageHeight}px (got ${width}x${height}). Use a full-body shot.`,
    );

  await ensureDirs();
  const fileName = `u_${randomUUID()}.jpg`;
  await writeFile(path.join(config.uploadDir, fileName), out.data);
  return {
    fileName,
    width,
    height,
    bytes: out.data.length,
    sha256: createHash("sha256").update(out.data).digest("hex"),
  };
}

/** Path-traversal-safe read of a stored file by its random name. */
export async function readStoredFile(
  fileName: string,
  kind: "upload" | "result",
): Promise<Buffer | null> {
  if (!SAFE_NAME.test(fileName) || fileName.includes("..")) return null;
  const base = kind === "result" ? resultsDir() : config.uploadDir;
  const full = path.resolve(base, fileName);
  if (!full.startsWith(path.resolve(base) + path.sep)) return null;
  try {
    return await readFile(full);
  } catch {
    return null;
  }
}

export async function writeResultFile(fileName: string, data: Buffer) {
  await ensureDirs();
  if (!SAFE_NAME.test(fileName)) throw new Error("unsafe file name");
  await writeFile(path.join(resultsDir(), fileName), data);
}

export async function deleteStoredFile(
  fileName: string,
  kind: "upload" | "result",
) {
  if (!SAFE_NAME.test(fileName) || fileName.includes("..")) return;
  const base = kind === "result" ? resultsDir() : config.uploadDir;
  await unlink(path.join(base, fileName)).catch(() => {});
}
