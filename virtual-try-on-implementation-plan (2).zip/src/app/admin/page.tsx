import { redirect } from "next/navigation";
import { getSessionUser } from "@/lib/auth";
import { listCategories } from "@/lib/catalog";
import AdminClient from "@/components/AdminClient";

export const metadata = { title: "Admin — Virtual Fit" };
export const dynamic = "force-dynamic";

export default async function AdminPage() {
  const user = await getSessionUser();
  if (!user) redirect("/login?next=/admin");
  if (user.role !== "admin") redirect("/");
  const cats = await listCategories();
  return <AdminClient categories={cats.map((c) => ({ id: c.id, name: c.name, slug: c.slug }))} />;
}
