import { ok } from "@/lib/api";
import { listProducts } from "@/lib/catalog";

export async function GET(req: Request) {
  const url = new URL(req.url);
  const items = await listProducts({
    categorySlug: url.searchParams.get("category"),
    q: url.searchParams.get("q"),
  });
  return ok({ products: items });
}
