import { describe, expect, it } from "vitest";
import { hashPassword, verifyPassword } from "@/lib/password";

describe("password hashing (bcrypt)", () => {
  it("hash → verify roundtrip", async () => {
    const hash = await hashPassword("correct-horse-battery");
    expect(hash).not.toContain("correct-horse");
    expect(hash.startsWith("$2")).toBe(true); // bcrypt marker
    await expect(verifyPassword("correct-horse-battery", hash)).resolves.toBe(true);
  });

  it("rejects wrong passwords", async () => {
    const hash = await hashPassword("s3cret-pass");
    await expect(verifyPassword("s3cret-pazz", hash)).resolves.toBe(false);
  });

  it("salts per hash (no deterministic hashes)", async () => {
    const a = await hashPassword("same-password");
    const b = await hashPassword("same-password");
    expect(a).not.toBe(b);
  });
});
