import { eq } from "drizzle-orm";
import { db } from "@/db";
import { categories, products } from "@/db/schema";
import { ApiError, handler, ok } from "@/lib/api";
import { attachSizes } from "@/lib/catalog";

type Ctx = { params: Promise<{ id: string }> };

export const GET = handler(async (_req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  const [row] = await db
    .select({ p: products, c: categories })
    .from(products)
    .leftJoin(categories, eq(categories.id, products.categoryId))
    .where(eq(products.id, id))
    .limit(1);
  if (!row || !row.p.active)
    throw new ApiError(404, "PRODUCT_NOT_FOUND", "Product not found.");
  const [dto] = await attachSizes([row]);
  return ok({ product: dto });
});
