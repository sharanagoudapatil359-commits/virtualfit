import { NextResponse } from "next/server";
import { ZodError, type ZodSchema } from "zod";

/**
 * Uniform JSON API shape:
 *   success: { "data": ... }
 *   failure: { "error": { "code": "SOME_CODE", "message": "...", "details"? } }
 */
export class ApiError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
    public details?: unknown,
  ) {
    super(message);
  }
}

export function ok<T>(data: T, status = 200) {
  return NextResponse.json({ data }, { status });
}

export function fail(
  status: number,
  code: string,
  message: string,
  details?: unknown,
) {
  return NextResponse.json(
    { error: { code, message, ...(details ? { details } : {}) } },
    { status },
  );
}

/** Parse + validate a JSON body against a zod schema. Throws ApiError. */
export async function parseBody<T>(req: Request, schema: ZodSchema<T>): Promise<T> {
  let raw: unknown;
  try {
    raw = await req.json();
  } catch {
    throw new ApiError(400, "INVALID_JSON", "Request body must be valid JSON.");
  }
  try {
    return schema.parse(raw);
  } catch (e) {
    if (e instanceof ZodError) {
      throw new ApiError(400, "VALIDATION_ERROR", "Invalid request fields.", {
        fields: e.issues.map((i) => ({
          path: i.path.join("."),
          message: i.message,
        })),
      });
    }
    throw e;
  }
}

/**
 * Route wrapper: converts ApiError / ZodError / unknown throws into the
 * uniform error envelope so handlers stay clean.
 */
export function handler<Ctx>(
  fn: (req: Request, ctx: Ctx) => Promise<Response>,
) {
  return async (req: Request, ctx: Ctx): Promise<Response> => {
    try {
      return await fn(req, ctx);
    } catch (e) {
      if (e instanceof ApiError) {
        return fail(e.status, e.code, e.message, e.details);
      }
      console.error("[api] unhandled error:", e);
      return fail(500, "INTERNAL_ERROR", "Unexpected server error.");
    }
  };
}
