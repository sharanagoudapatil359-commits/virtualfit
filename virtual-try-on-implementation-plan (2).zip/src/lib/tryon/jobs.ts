import type { TryonJob } from "@/db/schema";

export interface JobDto {
  id: string;
  status: string;
  size: string;
  productName?: string;
  productColorHex?: string;
  resultUrl: string | null;
  sourceUrl: string | null;
  errorCode: string | null;
  errorMessage: string | null;
  landmarks: unknown; // { width, height, points } | null
  imageWidth: number | null;
  imageHeight: number | null;
  warnings: string[];
  processingMs: number | null;
  createdAt: string;
}

export function jobDto(
  j: TryonJob,
  extra?: { productName?: string; productColorHex?: string; sourceFile?: string },
): JobDto {
  const lm = j.landmarks as { width?: number; height?: number } | null;
  return {
    id: j.id,
    status: j.status,
    size: j.size,
    imageWidth: typeof lm?.width === "number" ? lm.width : null,
    imageHeight: typeof lm?.height === "number" ? lm.height : null,
    productName: extra?.productName,
    productColorHex: extra?.productColorHex,
    resultUrl: j.resultFile ? `/api/files/${j.resultFile}` : null,
    sourceUrl: extra?.sourceFile ? `/api/files/${extra.sourceFile}` : null,
    errorCode: j.errorCode,
    errorMessage: j.errorMessage,
    landmarks: j.landmarks,
    warnings: Array.isArray(j.warnings) ? (j.warnings as string[]) : [],
    processingMs: j.processingMs,
    createdAt: j.createdAt.toISOString(),
  };
}
