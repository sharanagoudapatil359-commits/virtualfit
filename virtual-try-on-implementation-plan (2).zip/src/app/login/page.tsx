import AuthForm from "@/components/AuthForm";

export const metadata = { title: "Sign in — Virtual Fit" };

export default function LoginPage() {
  return <AuthForm mode="login" />;
}
