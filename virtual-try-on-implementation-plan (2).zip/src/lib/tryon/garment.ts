import type { GarmentTemplate } from "@/lib/constants";

/**
 * Procedural garment renderer. Each template is a stylised silhouette on a
 * 100x140 design grid, tinted per product and shaded with gradients, drawn
 * as SVG and rasterised by sharp. This doubles as catalog artwork and as
 * the warp source for the overlay try-on model.
 */

/** Darken/lighten a hex colour by -100..100. */
export function shade(hex: string, pct: number): string {
  const n = hex.replace("#", "");
  const num = parseInt(n.length === 3 ? n.split("").map((c) => c + c).join("") : n, 16);
  const amt = Math.round(2.55 * pct);
  const r = Math.max(0, Math.min(255, (num >> 16) + amt));
  const g = Math.max(0, Math.min(255, ((num >> 8) & 0xff) + amt));
  const b = Math.max(0, Math.min(255, (num & 0xff) + amt));
  return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}

const COLLAR = "M38 6 Q50 20 62 6";

function silhouette(template: GarmentTemplate, id: string): string {
  switch (template) {
    case "tee":
      return `<path d="M38 6 L20 12 L4 26 L16 44 L28 36 L30 122 L70 122 L72 36 L84 44 L96 26 L80 12 L62 6 Q50 20 38 6 Z" fill="url(#${id})"/>`;
    case "jacket":
      return `<path d="M30 8 L18 14 L4 30 L16 48 L27 40 L29 124 L71 124 L73 40 L84 48 L96 30 L82 14 L70 8 L58 20 L50 34 L42 20 Z" fill="url(#${id})"/>`;
    case "dress":
      return `<path d="M38 6 L22 12 L10 24 L21 38 L30 31 L34 56 L16 132 Q50 140 84 132 L66 56 L70 31 L79 38 L90 24 L78 12 L62 6 Q50 20 38 6 Z" fill="url(#${id})"/>`;
    case "pants":
      return `<path d="M27 6 L73 6 L75 132 L54 132 L50 58 L46 132 L25 132 Z" fill="url(#${id})"/>`;
    case "skirt":
      return `<path d="M33 6 L67 6 L69 14 L84 108 Q50 118 16 108 L31 14 Z" fill="url(#${id})"/>`;
  }
}

function details(template: GarmentTemplate, dark: string): string {
  const s = `stroke="${dark}" stroke-width="1.4" fill="none"`;
  switch (template) {
    case "tee":
      return `<path d="${COLLAR}" ${s} opacity="0.55"/><line x1="31.5" y1="116" x2="68.5" y2="116" ${s} opacity="0.5"/><line x1="17" y1="41" x2="27" y2="34" ${s} opacity="0.4"/><line x1="83" y1="41" x2="73" y2="34" ${s} opacity="0.4"/>`;
    case "jacket":
      return `<line x1="50" y1="34" x2="50" y2="122" stroke="${dark}" stroke-width="2.4" opacity="0.8"/><path d="M42 20 L50 34 L58 20" ${s} opacity="0.55"/><line x1="34" y1="96" x2="44" y2="96" ${s} opacity="0.45"/><line x1="56" y1="96" x2="66" y2="96" ${s} opacity="0.45"/>`;
    case "dress":
      return `<path d="${COLLAR}" ${s} opacity="0.55"/><path d="M34 56 Q50 62 66 56" ${s} opacity="0.5"/><path d="M30 88 Q50 94 70 88" ${s} opacity="0.3"/>`;
    case "pants":
      return `<rect x="27" y="6" width="46" height="8" fill="${dark}" opacity="0.55"/><line x1="50" y1="16" x2="50" y2="52" ${s} opacity="0.5"/><line x1="37" y1="16" x2="35" y2="126" ${s} opacity="0.3"/><line x1="63" y1="16" x2="65" y2="126" ${s} opacity="0.3"/>`;
    case "skirt":
      return `<rect x="33" y="6" width="34" height="8" fill="${dark}" opacity="0.55"/><path d="M24 78 Q50 86 76 78" ${s} opacity="0.35"/>`;
  }
}

/** Full SVG document with intrinsic pixel size for rasterisation. */
export function garmentSvg(
  template: GarmentTemplate,
  colorHex: string,
  width: number,
  height: number,
): string {
  const id = `g${Math.round(width)}x${Math.round(height)}`;
  const light = shade(colorHex, 18);
  const dark = shade(colorHex, -32);
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${Math.round(width)}" height="${Math.round(height)}" viewBox="0 0 100 140">
  <defs>
    <linearGradient id="${id}" x1="0" y1="0" x2="1" y2="0.25">
      <stop offset="0" stop-color="${dark}"/>
      <stop offset="0.42" stop-color="${light}"/>
      <stop offset="0.62" stop-color="${colorHex}"/>
      <stop offset="1" stop-color="${dark}"/>
    </linearGradient>
  </defs>
  ${silhouette(template, id)}
  ${details(template, dark)}
</svg>`;
}
