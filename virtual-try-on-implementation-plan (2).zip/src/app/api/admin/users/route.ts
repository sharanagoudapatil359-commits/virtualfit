import { desc } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { handler, ok } from "@/lib/api";
import { publicUser, requireAdmin } from "@/lib/auth";

/** GET /api/admin/users — account list (no password hashes). */
export const GET = handler(async () => {
  await requireAdmin();
  const rows = await db
    .select()
    .from(users)
    .orderBy(desc(users.createdAt))
    .limit(200);
  return ok({ users: rows.map(publicUser) });
});
