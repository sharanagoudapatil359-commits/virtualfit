import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { cartItems, products, productSizes } from "@/db/schema";
import { computeTotals, type Totals } from "@/lib/orders";

export interface CartItemDto {
  id: string;
  productId: string;
  name: string;
  colorHex: string;
  template: string;
  imageUrl: string;
  size: string;
  qty: number;
  unitPriceCents: number;
  stock: number;
}

export interface CartView {
  items: CartItemDto[];
  totals: Totals;
}

/** Full cart view for a user (items joined with product + per-size stock). */
export async function getCart(userId: string): Promise<CartView> {
  const rows = await db
    .select({
      item: cartItems,
      name: products.name,
      colorHex: products.colorHex,
      template: products.garmentTemplate,
      priceCents: products.priceCents,
      stock: productSizes.stock,
    })
    .from(cartItems)
    .innerJoin(products, eq(products.id, cartItems.productId))
    .innerJoin(
      productSizes,
      and(
        eq(productSizes.productId, cartItems.productId),
        eq(productSizes.size, cartItems.size),
      ),
    )
    .where(eq(cartItems.userId, userId));

  const items: CartItemDto[] = rows.map((r) => ({
    id: r.item.id,
    productId: r.item.productId,
    name: r.name,
    colorHex: r.colorHex,
    template: r.template,
    imageUrl: `/api/products/${r.item.productId}/image`,
    size: r.item.size,
    qty: r.item.qty,
    unitPriceCents: r.priceCents,
    stock: r.stock,
  }));

  const totals = computeTotals(
    items.map((i) => ({ unitPriceCents: i.unitPriceCents, qty: i.qty })),
  );
  return { items, totals };
}
