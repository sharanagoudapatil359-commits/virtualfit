import { ok } from "@/lib/api";
import { listCategories } from "@/lib/catalog";

export async function GET() {
  const rows = await listCategories();
  return ok({ categories: rows });
}
