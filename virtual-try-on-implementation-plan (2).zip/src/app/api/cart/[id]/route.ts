import { and, eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { cartItems, productSizes } from "@/db/schema";
import { ApiError, handler, ok, parseBody } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { getCart } from "@/lib/cart";

type Ctx = { params: Promise<{ id: string }> };

async function ownItem(userId: string, id: string) {
  const [row] = await db
    .select()
    .from(cartItems)
    .where(and(eq(cartItems.id, id), eq(cartItems.userId, userId)))
    .limit(1);
  if (!row) throw new ApiError(404, "CART_ITEM_NOT_FOUND", "Cart item not found.");
  return row;
}

const patchSchema = z.object({ qty: z.number().int().min(1).max(5) });

export const PATCH = handler(async (req: Request, ctx: Ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const { qty } = await parseBody(req, patchSchema);
  const item = await ownItem(user.id, id);

  const [sizeRow] = await db
    .select()
    .from(productSizes)
    .where(
      and(eq(productSizes.productId, item.productId), eq(productSizes.size, item.size)),
    )
    .limit(1);
  if (!sizeRow || qty > sizeRow.stock)
    throw new ApiError(409, "OUT_OF_STOCK", `Only ${sizeRow?.stock ?? 0} left in size ${item.size}.`, {
      available: sizeRow?.stock ?? 0,
    });

  await db.update(cartItems).set({ qty }).where(eq(cartItems.id, item.id));
  return ok(await getCart(user.id));
});

export const DELETE = handler(async (_req: Request, ctx: Ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  await ownItem(user.id, id);
  await db.delete(cartItems).where(eq(cartItems.id, id));
  return ok(await getCart(user.id));
});
