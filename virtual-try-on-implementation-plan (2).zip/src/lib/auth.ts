import { cookies } from "next/headers";
import { createHash, randomBytes } from "crypto";
import { and, eq, gt } from "drizzle-orm";
import { db } from "@/db";
import { sessions, users, type User } from "@/db/schema";
import { config } from "@/lib/config";
import { ApiError } from "@/lib/api";

/* ---------------- password hashing (bcrypt) ---------------- */
export { hashPassword, verifyPassword } from "@/lib/password";

/* ---------------- opaque session tokens ----------------
   Cookie holds a random 256-bit token; only its sha256 is stored,
   so a DB leak does not leak usable session tokens.               */
const sha256 = (s: string) => createHash("sha256").update(s).digest("hex");

export async function createSession(userId: string): Promise<void> {
  const token = randomBytes(32).toString("base64url");
  const expiresAt = new Date(
    Date.now() + config.sessionTtlDays * 24 * 60 * 60 * 1000,
  );
  await db.insert(sessions).values({ userId, tokenHash: sha256(token), expiresAt });
  const store = await cookies();
  store.set(config.cookieName, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    expires: expiresAt,
  });
}

export async function destroySession(): Promise<void> {
  const store = await cookies();
  const token = store.get(config.cookieName)?.value;
  if (token) {
    await db.delete(sessions).where(eq(sessions.tokenHash, sha256(token)));
  }
  store.delete(config.cookieName);
}

/** Current authenticated user or null (expired/missing tokens → null). */
export async function getSessionUser(): Promise<User | null> {
  const store = await cookies();
  const token = store.get(config.cookieName)?.value;
  if (!token) return null;
  const rows = await db
    .select({ user: users })
    .from(sessions)
    .innerJoin(users, eq(users.id, sessions.userId))
    .where(
      and(
        eq(sessions.tokenHash, sha256(token)),
        gt(sessions.expiresAt, new Date()),
      ),
    )
    .limit(1);
  return rows[0]?.user ?? null;
}

export async function requireUser(): Promise<User> {
  const user = await getSessionUser();
  if (!user) throw new ApiError(401, "AUTH_REQUIRED", "Please sign in.");
  return user;
}

export async function requireAdmin(): Promise<User> {
  const user = await requireUser();
  if (user.role !== "admin") {
    throw new ApiError(403, "ADMIN_REQUIRED", "Administrator access required.");
  }
  return user;
}

/** Public-safe user payload (never leak the password hash). */
export function publicUser(u: User) {
  return { id: u.id, name: u.name, email: u.email, role: u.role };
}
