import { eq } from "drizzle-orm";
import sharp from "sharp";
import { db } from "@/db";
import { products } from "@/db/schema";
import { fail } from "@/lib/api";
import { GARMENT_TEMPLATES, type GarmentTemplate } from "@/lib/constants";
import { garmentSvg } from "@/lib/tryon/garment";

type Ctx = { params: Promise<{ id: string }> };

/** Catalog artwork: deterministic garment illustration (transparent PNG). */
export async function GET(_req: Request, ctx: Ctx) {
  const { id } = await ctx.params;
  const [p] = await db.select().from(products).where(eq(products.id, id)).limit(1);
  if (!p) return fail(404, "PRODUCT_NOT_FOUND", "Product not found.");
  const template = (GARMENT_TEMPLATES as readonly string[]).includes(p.garmentTemplate)
    ? (p.garmentTemplate as GarmentTemplate)
    : "tee";
  const svg = garmentSvg(template, p.colorHex, 420, 588);
  const png = await sharp(Buffer.from(svg)).png().toBuffer();
  return new Response(new Uint8Array(png), {
    headers: {
      "content-type": "image/png",
      "cache-control": "public, max-age=31536000, immutable",
    },
  });
}
