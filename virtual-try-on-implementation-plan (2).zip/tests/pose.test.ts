import { describe, expect, it } from "vitest";
import { analyzeMask, PoseError } from "@/lib/tryon/pose";

const W = 48;
const H = 96;
const IW = 480;
const IH = 960;

function emptyMask() {
  return new Uint8Array(W * H);
}
function bar(mask: Uint8Array, x0: number, w: number, y0 = 10, y1 = 86) {
  for (let y = y0; y <= y1; y++) for (let x = x0; x < x0 + w; x++) mask[y * W + x] = 1;
  return mask;
}
/** Centered human-ish bar: ratio ≈ 18%, aspect ≈ 4.75 → confident detection. */
function personMask() {
  return bar(emptyMask(), 19, 10);
}

describe("analyzeMask (pose grid analysis)", () => {
  it("throws NO_PERSON on an empty frame", () => {
    expect(() => analyzeMask(emptyMask(), W, H, IW, IH)).toThrowError(PoseError);
    try {
      analyzeMask(emptyMask(), W, H, IW, IH);
    } catch (e) {
      expect((e as PoseError).code).toBe("NO_PERSON");
    }
  });

  it("throws NO_PERSON when subject/background are inseparable", () => {
    const full = new Uint8Array(W * H).fill(1);
    try {
      analyzeMask(full, W, H, IW, IH);
      expect.unreachable();
    } catch (e) {
      expect((e as PoseError).code).toBe("NO_PERSON");
    }
  });

  it("throws MULTIPLE_PEOPLE for two separated subjects", () => {
    const m = emptyMask();
    bar(m, 6, 6);
    bar(m, 36, 6);
    try {
      analyzeMask(m, W, H, IW, IH);
      expect.unreachable();
    } catch (e) {
      expect((e as PoseError).code).toBe("MULTIPLE_PEOPLE");
    }
  });

  it("locates ordered landmarks for a single centred subject", () => {
    const r = analyzeMask(personMask(), W, H, IW, IH);
    const L = r.landmarks;
    // vertical ordering must follow anatomy
    expect(L.leftShoulder.y).toBeLessThan(L.waist.y);
    expect(L.waist.y).toBeLessThan(L.leftHip.y);
    expect(L.leftHip.y).toBeLessThan(L.leftKnee.y);
    expect(L.leftKnee.y).toBeLessThan(L.leftAnkle.y);
    // horizontal sanity
    expect(L.leftShoulder.x).toBeLessThan(L.rightShoulder.x);
    expect(L.leftHip.x).toBeLessThan(L.rightHip.x);
    // symmetric bar → frontal & confident
    expect(r.frontality).toBeGreaterThan(0.8);
    expect(r.confidence).toBeGreaterThan(0.6);
    // bounding box in image pixels
    expect(r.personBox.width).toBeGreaterThan(0);
    expect(r.personBox.height).toBeGreaterThan(r.personBox.width);
  });

  it("flags strongly asymmetric silhouettes as non-frontal", () => {
    const m = emptyMask();
    bar(m, 10, 8); // torso
    for (let y = 20; y <= 40; y++) for (let x = 18; x < 34; x++) m[y * W + x] = 1; // arm blown out right
    const r = analyzeMask(m, W, H, IW, IH);
    expect(r.frontality).toBeLessThan(0.75);
  });
});
