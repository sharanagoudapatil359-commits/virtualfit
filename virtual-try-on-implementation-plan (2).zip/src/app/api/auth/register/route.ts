import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { users } from "@/db/schema";
import { ApiError, handler, ok, parseBody } from "@/lib/api";
import { createSession, hashPassword, publicUser } from "@/lib/auth";
import { config } from "@/lib/config";
import { clientIp, rateLimit } from "@/lib/ratelimit";

const registerSchema = z.object({
  name: z.string().trim().min(2, "Name must be at least 2 characters.").max(60),
  email: z.string().trim().email("Enter a valid email address.").max(120),
  password: z
    .string()
    .min(8, "Password must be at least 8 characters.")
    .max(72, "Password must be 72 characters or fewer."),
});

export const POST = handler(async (req: Request) => {
  rateLimit(`auth:${clientIp(req)}`, config.limits.auth, 10 * 60 * 1000);
  const body = await parseBody(req, registerSchema);
  const email = body.email.toLowerCase();

  const existing = await db
    .select({ id: users.id })
    .from(users)
    .where(eq(users.email, email))
    .limit(1);
  if (existing.length > 0)
    throw new ApiError(409, "EMAIL_TAKEN", "An account with this email already exists.");

  const passwordHash = await hashPassword(body.password);
  const [user] = await db
    .insert(users)
    .values({ name: body.name, email, passwordHash })
    .returning();
  await createSession(user.id);
  return ok({ user: publicUser(user) }, 201);
});
