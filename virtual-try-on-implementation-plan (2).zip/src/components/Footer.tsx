import Link from "next/link";
import { Aperture } from "lucide-react";

export default function Footer() {
  return (
    <footer className="border-t border-white/5 bg-panel">
      <div className="mx-auto grid max-w-7xl gap-10 px-5 py-14 md:grid-cols-3">
        <div>
          <div className="flex items-center gap-2.5">
            <span className="grid h-8 w-8 place-items-center rounded-lg bg-lime text-ink">
              <Aperture size={17} strokeWidth={2.4} />
            </span>
            <span className="font-display text-[15px] font-semibold">VIRTUAL<span className="text-lime">FIT</span></span>
          </div>
          <p className="mt-4 max-w-xs text-sm leading-relaxed text-mute">
            Wear it before you buy it. Pose-aware virtual try-on, straight from
            your camera roll.
          </p>
        </div>
        <div className="text-sm">
          <p className="mb-3 text-[11px] font-semibold uppercase tracking-[0.2em] text-mute">Shop</p>
          <ul className="space-y-2 text-cream/70">
            <li><Link href="/catalog" className="hover:text-lime">Catalog</Link></li>
            <li><Link href="/tryon" className="hover:text-lime">Try-On Studio</Link></li>
            <li><Link href="/cart" className="hover:text-lime">Cart</Link></li>
            <li><Link href="/wishlist" className="hover:text-lime">Wishlist</Link></li>
          </ul>
        </div>
        <div className="text-sm">
          <p className="mb-3 text-[11px] font-semibold uppercase tracking-[0.2em] text-mute">Privacy</p>
          <ul className="space-y-2 text-cream/70">
            <li>Photos are stored privately, never shared.</li>
            <li>You can delete your uploads at any time.</li>
            <li>EXIF metadata is stripped on upload.</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-white/5 py-5 text-center text-xs text-mute">
        Virtual Fit — MVP vertical slice &middot; overlay try-on engine v1
      </div>
    </footer>
  );
}
