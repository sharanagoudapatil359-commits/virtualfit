import { fail, ok } from "@/lib/api";
import { getSessionUser, publicUser } from "@/lib/auth";

export async function GET() {
  const user = await getSessionUser();
  if (!user) return fail(401, "AUTH_REQUIRED", "Not signed in.");
  return ok({ user: publicUser(user) });
}
