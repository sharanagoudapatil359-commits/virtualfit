import Link from "next/link";
import { ArrowRight, Asterisk, Check, ScanFace, ScanLine, Shirt, ShoppingBag, Upload } from "lucide-react";
import { listCategories, listProducts } from "@/lib/catalog";
import ProductCard from "@/components/ProductCard";
import Reveal from "@/components/Reveal";

const MARQUEE = [
  "POSE DETECTION",
  "GARMENT MAPPING",
  "TRUE-TO-SIZE FIT",
  "INSTANT PREVIEW",
  "ZERO RETURNS",
];

export default async function Home() {
  const [products, cats] = await Promise.all([listProducts({}), listCategories()]);
  const featured = products.slice(0, 4);

  return (
    <div>
      {/* ---------------- HERO ---------------- */}
      <section className="relative overflow-hidden border-b border-white/5">
        <div className="mx-auto grid max-w-7xl gap-10 px-5 pb-16 pt-14 md:grid-cols-[1.15fr_1fr] md:items-center md:pt-20">
          <div>
            <Reveal>
              <p className="mb-5 inline-flex items-center gap-2 rounded-full border border-lime/30 bg-lime/10 px-3.5 py-1.5 text-[11px] font-semibold uppercase tracking-[0.22em] text-lime">
                <span className="h-1.5 w-1.5 rounded-full bg-lime pulse-dot" />
                Virtual try-on engine v1
              </p>
            </Reveal>
            <Reveal delay={80}>
              <h1 className="font-display text-[clamp(2.4rem,6.4vw,5rem)] font-extrabold leading-[1.02] tracking-tight">
                WEAR IT
                <br />
                <span className="text-stroke">BEFORE YOU</span>
                <br />
                BUY IT<span className="text-lime">.</span>
              </h1>
            </Reveal>
            <Reveal delay={160}>
              <p className="mt-6 max-w-md text-[15px] leading-relaxed text-mute">
                Upload one full-body photo. Our pipeline detects your pose,
                anchors the garment to your frame, and renders the fit in
                seconds — no fitting room required.
              </p>
            </Reveal>
            <Reveal delay={240}>
              <div className="mt-8 flex flex-wrap items-center gap-3">
                <Link
                  href="/tryon"
                  className="group inline-flex items-center gap-2 rounded-full bg-lime px-6 py-3 text-sm font-bold uppercase tracking-[0.08em] text-ink transition hover:bg-cream"
                >
                  Open the Studio
                  <ArrowRight size={16} className="transition group-hover:translate-x-1" />
                </Link>
                <Link
                  href="/catalog"
                  className="rounded-full border border-white/15 px-6 py-3 text-sm font-bold uppercase tracking-[0.08em] text-cream/80 transition hover:border-cream/50 hover:text-cream"
                >
                  Browse catalog
                </Link>
              </div>
            </Reveal>
            <Reveal delay={320}>
              <dl className="mt-12 grid max-w-md grid-cols-3 gap-4">
                {[
                  ["11", "garments live"],
                  ["~2s", "render time"],
                  ["10", "pose landmarks"],
                ].map(([v, l]) => (
                  <div key={l} className="border-l border-white/10 pl-3">
                    <dt className="font-display text-xl font-bold text-lime">{v}</dt>
                    <dd className="mt-1 text-[11px] uppercase tracking-[0.14em] text-mute">{l}</dd>
                  </div>
                ))}
              </dl>
            </Reveal>
          </div>

          <Reveal delay={200} className="relative">
            <div className="relative mx-auto max-w-sm">
              <div className="overflow-hidden rounded-t-[10rem] rounded-b-3xl border border-white/10">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src="https://images.pexels.com/photos/7752438/pexels-photo-7752438.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800"
                  alt="Editorial studio model"
                  className="aspect-[2/3] w-full object-cover"
                />
                <div className="pointer-events-none absolute inset-0">
                  <div className="scanline" />
                </div>
              </div>
              {[
                { top: "14%", left: "-8%", label: "SUBJECT LOCKED", color: "text-lime border-lime/40" },
                { top: "44%", right: "-10%", label: "GARMENT MAPPED", color: "text-violet border-violet/40" },
                { bottom: "10%", left: "-6%", label: "FIT SCORE 0.92", color: "text-cream border-white/20" },
              ].map((c) => (
                <div
                  key={c.label}
                  style={{ top: c.top, left: c.left, right: c.right, bottom: c.bottom }}
                  className={`absolute rounded-full border bg-ink/80 px-3 py-1.5 text-[10px] font-bold tracking-[0.18em] backdrop-blur ${c.color}`}
                >
                  {c.label}
                </div>
              ))}
            </div>
          </Reveal>
        </div>

        <div className="overflow-hidden border-t border-white/5 py-3.5">
          <div className="marquee-track flex w-max items-center gap-8">
            {[...MARQUEE, ...MARQUEE, ...MARQUEE, ...MARQUEE].map((t, i) => (
              <span key={i} className="flex items-center gap-8 text-[12px] font-bold uppercase tracking-[0.3em] text-cream/40">
                {t} <Asterisk size={14} className="text-lime" />
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* ---------------- CATEGORIES ---------------- */}
      <section className="mx-auto max-w-7xl px-5 py-16">
        <Reveal>
          <div className="mb-8 flex items-end justify-between">
            <h2 className="font-display text-2xl font-bold md:text-3xl">Shop by category</h2>
            <Link href="/catalog" className="text-sm text-mute transition hover:text-lime">
              View all →
            </Link>
          </div>
        </Reveal>
        <div className="grid grid-cols-2 gap-4 md:grid-cols-5">
          {cats.map((c, i) => (
            <Reveal key={c.id} delay={i * 70}>
              <Link
                href={`/catalog?category=${c.slug}`}
                className="group relative flex aspect-[4/5] flex-col justify-between overflow-hidden rounded-3xl border border-white/8 bg-panel p-5 transition hover:border-lime/40"
              >
                <span className="font-display text-4xl font-extrabold text-white/8 transition group-hover:text-lime/25">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <div>
                  <p className="font-display text-lg font-bold">{c.name}</p>
                  <p className="mt-1 flex items-center gap-1 text-xs text-mute transition group-hover:text-lime">
                    Explore <ArrowRight size={12} />
                  </p>
                </div>
                <div className="absolute -right-6 -top-6 h-24 w-24 rounded-full bg-violet/10 blur-2xl transition group-hover:bg-lime/15" />
              </Link>
            </Reveal>
          ))}
        </div>
      </section>

      {/* ---------------- NEW DROPS ---------------- */}
      <section className="mx-auto max-w-7xl px-5 pb-20">
        <Reveal>
          <div className="mb-8 flex items-end justify-between">
            <h2 className="font-display text-2xl font-bold md:text-3xl">New drops</h2>
            <Link href="/catalog" className="text-sm text-mute transition hover:text-lime">
              Full catalog →
            </Link>
          </div>
        </Reveal>
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {featured.map((p, i) => (
            <Reveal key={p.id} delay={i * 80}>
              <ProductCard product={p} />
            </Reveal>
          ))}
        </div>
      </section>

      {/* ---------------- HOW IT WORKS ---------------- */}
      <section className="border-y border-white/5 bg-panel">
        <div className="mx-auto max-w-7xl px-5 py-16">
          <Reveal>
            <p className="mb-3 text-[11px] font-semibold uppercase tracking-[0.24em] text-violet">
              The pipeline
            </p>
            <h2 className="mb-10 font-display text-2xl font-bold md:text-3xl">
              From camera roll to checkout
            </h2>
          </Reveal>
          <div className="grid gap-4 md:grid-cols-4">
            {[
              { icon: Upload, t: "Upload a photo", d: "Full-body, front-facing, plain background. EXIF stripped, stored privately." },
              { icon: ScanLine, t: "Pose detection", d: "Ten body landmarks are located and quality-checked — multi-person and low-res shots are rejected gracefully." },
              { icon: Shirt, t: "Garment overlay", d: "The garment is warped to your shoulders and hips, scaled by the size you picked." },
              { icon: ShoppingBag, t: "Decide & checkout", d: "Wishlist or cart straight from the result. Stock is reserved per size." },
            ].map((s, i) => (
              <Reveal key={s.t} delay={i * 90}>
                <div className="h-full rounded-3xl border border-white/8 bg-ink p-6">
                  <div className="mb-5 flex items-center justify-between">
                    <span className="grid h-10 w-10 place-items-center rounded-xl bg-violet/15 text-violet">
                      <s.icon size={18} />
                    </span>
                    <span className="font-display text-sm text-white/20">0{i + 1}</span>
                  </div>
                  <h3 className="mb-2 font-semibold">{s.t}</h3>
                  <p className="text-[13px] leading-relaxed text-mute">{s.d}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* ---------------- CTA ---------------- */}
      <section className="mx-auto max-w-7xl px-5 py-20">
        <Reveal>
          <div className="relative overflow-hidden rounded-[2.5rem] border border-lime/25 bg-gradient-to-br from-lime/12 via-panel to-violet/12 p-10 text-center md:p-16">
            <h2 className="mx-auto max-w-2xl font-display text-3xl font-extrabold leading-tight md:text-4xl">
              Your fitting room is in your pocket.
            </h2>
            <p className="mx-auto mt-4 max-w-md text-sm text-mute">
              Create a free account and run your first try-on in under a minute.
            </p>
            <div className="mt-8 flex flex-wrap justify-center gap-3">
              <Link
                href="/register"
                className="inline-flex items-center gap-2 rounded-full bg-cream px-7 py-3 text-sm font-bold uppercase tracking-[0.08em] text-ink transition hover:bg-lime"
              >
                Create account <ArrowRight size={15} />
              </Link>
              <Link
                href="/tryon"
                className="rounded-full border border-white/20 px-7 py-3 text-sm font-bold uppercase tracking-[0.08em] text-cream/80 transition hover:border-cream/50"
              >
                Try the studio
              </Link>
            </div>
            <div className="mt-8 flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-xs text-mute">
              {["No card required", "Delete photos anytime", "Free returns"].map((t) => (
                <span key={t} className="inline-flex items-center gap-1.5">
                  <Check size={13} className="text-lime" /> {t}
                </span>
              ))}
            </div>
          </div>
        </Reveal>
      </section>
    </div>
  );
}
