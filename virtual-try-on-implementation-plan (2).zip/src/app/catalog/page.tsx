import Link from "next/link";
import { Search } from "lucide-react";
import { listCategories, listProducts } from "@/lib/catalog";
import ProductCard from "@/components/ProductCard";
import Reveal from "@/components/Reveal";

export const dynamic = "force-dynamic";

export default async function CatalogPage({
  searchParams,
}: {
  searchParams: Promise<{ category?: string; q?: string }>;
}) {
  const sp = await searchParams;
  const [products, cats] = await Promise.all([
    listProducts({ categorySlug: sp.category ?? null, q: sp.q ?? null }),
    listCategories(),
  ]);

  const chip = (label: string, href: string, active: boolean) => (
    <Link
      key={label}
      href={href}
      className={`whitespace-nowrap rounded-full border px-4 py-1.5 text-xs font-semibold uppercase tracking-[0.1em] transition ${
        active
          ? "border-lime bg-lime text-ink"
          : "border-white/12 text-cream/60 hover:border-cream/40 hover:text-cream"
      }`}
    >
      {label}
    </Link>
  );

  return (
    <div className="mx-auto max-w-7xl px-5 py-12">
      <Reveal>
        <p className="mb-2 text-[11px] font-semibold uppercase tracking-[0.24em] text-violet">
          Catalog
        </p>
        <h1 className="font-display text-3xl font-extrabold md:text-4xl">
          Everything, tryable.
        </h1>
        <p className="mt-3 max-w-lg text-sm text-mute">
          Pick a garment, choose your size, then hit <span className="text-lime">Try</span> to see
          it on your own photo in the Studio.
        </p>
      </Reveal>

      <div className="mt-8 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div className="flex gap-2 overflow-x-auto pb-1">
          {chip("All", "/catalog", !sp.category)}
          {cats.map((c) =>
            chip(c.name, `/catalog?category=${c.slug}${sp.q ? `&q=${sp.q}` : ""}`, sp.category === c.slug),
          )}
        </div>
        <form action="/catalog" className="relative md:w-72">
          {sp.category && <input type="hidden" name="category" value={sp.category} />}
          <Search size={15} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-mute" />
          <input
            name="q"
            defaultValue={sp.q ?? ""}
            placeholder="Search garments…"
            className="input pl-9"
          />
        </form>
      </div>

      {products.length === 0 ? (
        <div className="mt-16 rounded-3xl border border-dashed border-white/15 p-16 text-center">
          <p className="font-display text-lg">Nothing matches that filter.</p>
          <Link href="/catalog" className="mt-3 inline-block text-sm text-lime hover:underline">
            Clear filters →
          </Link>
        </div>
      ) : (
        <div className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
          {products.map((p, i) => (
            <Reveal key={p.id} delay={(i % 4) * 60}>
              <ProductCard product={p} />
            </Reveal>
          ))}
        </div>
      )}
    </div>
  );
}
