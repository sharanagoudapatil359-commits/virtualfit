# Virtual Fit — Architecture, Schema & Runbook

> Companion doc to the runnable code in this repo. Everything referenced below
> exists and runs; the only staged parts are the real generative try-on model
> and Redis rate limiting, both behind explicit swap-in interfaces.

---

## 0. Assumptions

- **Single deployable full-stack app:** Next.js 16 (App Router, React 19, TS) instead of a
  separate Express/FastAPI backend. Route handlers under `src/app/api/*` provide the REST API;
  the same conventions apply if you later split the API into a standalone service
  (see §2.3). Requested HTML/CSS/vanilla-JS learning goals are preserved via plain
  flex/grid layouts and small typed client components (framework benefits noted inline).
- **Database:** PostgreSQL via Drizzle ORM (prod). For SQLite-style local dev, point
  `DATABASE_URL` at any PG instance; a SQLite port only requires swapping the driver in
  `src/db/index.ts` and `pg-core` column helpers in `src/db/schema.ts`.
- **AI/CV:** OpenCV-equivalent preprocessing via **sharp** (orient/resize/re-encode),
  pose detection via a **deterministic heuristic segmenter** (drop-in compatible with
  MediaPipe Pose — same landmark contract), garment application via geometric warp'
  overlay. A real generative/diffusion try-on model plugs in through `TryOnModel`
  (`src/lib/tryon/model.ts`), either in-process or via `TRYON_PROVIDER=http`.
- **Auth:** bcrypt-hashed passwords, opaque session tokens (sha256 stored server-side),
  `role` column for admin separation. JWT alternative noted (`.env` `JWT_SECRET`).
- **Money** is integer cents; sizes are a fixed enum `XS..XXL` for the MVP.

---

## 1. Folder structure & module boundaries

```
<PROJECT_ROOT>/
├─ src/
│  ├─ app/
│  │  ├─ page.tsx / catalog / tryon / cart / wishlist / login / register / admin   # pages
│  │  ├─ api/
│  │  │  ├─ auth/{register,login,logout,me}       # 1. User module
│  │  │  ├─ admin/{products,products/[id],orders,users,users/[id]}   # 2. Admin module
│  │  │  ├─ categories, products, products/[id], products/[id]/image # 3. Product module
│  │  │  ├─ uploads, uploads/[id], files/[name]   # 4. Image upload module
│  │  │  ├─ tryon, tryon/[id]                     # 5. Virtual try-on module
│  │  │  ├─ cart, cart/[id], wishlist, orders     # 6. Cart module
│  │  │  └─ health/
│  ├─ components/   Navbar, Footer, Toast, Reveal, ProductCard, AuthForm,
│  │                 TryOnStudio, CompareSlider, AdminClient
│  ├─ db/schema.ts  # all tables; src/db/index.ts = pooled Drizzle client
│  └─ lib/
│     ├─ api.ts auth.ts ratelimit.ts uploads.ts catalog.ts cart.ts orders.ts
│     ├─ constants.ts config.ts admin-schema.ts
│     └─ tryon/{pose,garment,model,pipeline,jobs}.ts   # CV core, isolated
├─ scripts/seed.ts          # idempotent seed (catalog, admin, demo user)
├─ tests/                   # vitest: unit + integration
├─ <UPLOAD_DIR>/            # default ./uploads — OUTSIDE web root, served by /api/files
└─ docs/ARCHITECTURE.md     # this file
```

**Boundary rules:** pages → API routes → `lib/*` services → `db`. CV code never touches
HTTP or SQL; routes never contain business math (see `lib/orders.ts`, `lib/cart.ts`).

## 2. Data flow: upload → try-on result

1. `POST /api/uploads` (multipart `photo` field): auth → rate-limit → size cap → magic-byte
   sniff (JPEG/PNG/WebP) → decode via sharp (`rotate()` auto-orients + strips EXIF) →
   dimension gates → re-encode JPEG → write `<UPLOAD_DIR>/u_<uuid>.jpg` → row in `uploads`.
2. `POST /api/tryon {uploadId, productId, size}`: auth → rate-limit → ownership/product/
   size/stock guards → create `tryon_jobs(status=processing)` → `runTryOnPipeline`:
   - **preprocess:** orient, cap width 1600px, JPEG q90.
   - `detectPose()` → `PoseResult { landmarks(10 keypoints), personBox, confidence, frontality, warnings }`.
   - `TryOnModel.tryOn()` — default `OverlayTryOnModel`: SVG garment → rasterize → scale by
     `SIZE_SCALE[size]` → anchor at shoulders/hips → rotate by shoulder tilt → `composite()`.
3. Result → `<UPLOAD_DIR>/results/r_<jobId>.jpg`, job → `completed` with landmarks + timings.
4. Client renders `<CompareSlider>` (before/after) + optional pose-debug SVG overlay.
5. Failures update the job (`status=failed, errorCode`) and return a mapped HTTP status.

### 2.3 Swapping pieces
- **Real try-on model:** `TRYON_PROVIDER=http` + `TRYON_API_URL/TRYON_API_KEY` →
  `HttpTryOnModel` POSTs `{image_base64, garment, size, pose}` and expects `{image_base64}`.
- **MediaPipe instead of heuristics:** implement `detectPose()` against
  `@mediapipe/tasks-vision` PoseLandmarker (Node or browser-side) returning the same
  `PoseResult`; nothing else changes. A Python sidecar option:

```python
# sidecar/main.py — FastAPI + MediaPipe (uvicorn sidecar.main:app)
@app.post("/pose")
async def pose(file: UploadFile):
    img = cv2.imdecode(np.frombuffer(await file.read(), np.uint8), cv2.IMREAD_COLOR)
    res = landmarker.detect(mp.Image(image_format=mp.ImageFormat.SRGB, data=img))
    if not res.pose_landmarks: raise HTTPException(422, "NO_PERSON")
    return {"landmarks": normalize(res.pose_landmarks[0])}  # → PoseResult shape
```

- **Standalone API service:** lift `src/app/api/*` handlers into Express/FastAPI; handlers
  already return plain `{data}|{error}` JSON and don't depend on Next primitives beyond
  the cookie helper in `lib/auth.ts` (swap for Authorization headers + JWT).

## 3. API endpoints

All JSON. Success `{data}`, failure `{error:{code,message,details?}}`.

| Method | Path | Request | Response → Codes |
|---|---|---|---|
| POST | /api/auth/register | `{name,email,password}` | 201 `{user}` → 409 EMAIL_TAKEN, 400 VALIDATION_ERROR, 429 |
| POST | /api/auth/login | `{email,password}` | 200 `{user}` → 401 INVALID_CREDENTIALS |
| POST | /api/auth/logout | — | 200 |
| GET  | /api/auth/me | — | 200 `{user}` / 401 AUTH_REQUIRED |
| GET  | /api/categories | — | 200 `{categories[]}` |
| GET  | /api/products?category=&q= | — | 200 `{products[]}` (sizes+stock, imageUrl) |
| GET  | /api/products/:id | — | 200 `{product}` / 404 PRODUCT_NOT_FOUND |
| GET  | /api/products/:id/image | — | PNG garment illustration |
| POST | /api/uploads | multipart `photo` | 201 `{uploadId,url,width,height}` → 400 NO_FILE, 413 FILE_TOO_LARGE, 415 UNSUPPORTED_MEDIA_TYPE, 422 MALFORMED_IMAGE / IMAGE_TOO_SMALL, 401, 429 |
| DELETE | /api/uploads/:id | — | 200 → 404 UPLOAD_NOT_FOUND |
| GET  | /api/files/:name | cookie | JPEG stream → 401 / 403 FORBIDDEN / 404 |
| POST | /api/tryon | `{uploadId,productId,size}` | 201 `{job{resultUrl,landmarks,warnings,processingMs}}` → 400 UNSUPPORTED_CATEGORY/INVALID_SIZE, 404 UPLOAD_NOT_FOUND/PRODUCT_NOT_FOUND, 409 OUT_OF_STOCK, 422 LOW_RESOLUTION/NO_PERSON/MULTIPLE_PEOPLE/UNCLEAR_POSE, 502 MODEL_ERROR |
| GET  | /api/tryon, /api/tryon/:id | — | job list / single job (polling-ready) |
| GET/POST | /api/cart | `{productId,size,qty}` | 200/201 `{items,totals}` → 409 OUT_OF_STOCK |
| PATCH/DELETE | /api/cart/:id | `{qty}` | 200 cart → 404 CART_ITEM_NOT_FOUND, 409 |
| GET/POST/DELETE | /api/wishlist | `{productId}` | idempotent add/remove |
| POST | /api/orders | — (checkout from cart) | 201 `{order}` → 400 CART_EMPTY, 409 OUT_OF_STOCK `{issues[]}` |
| GET  | /api/orders | — | order history |
| POST/PATCH | /api/admin/products(/:id) | product payload | admin only, 403 ADMIN_REQUIRED |
| GET | /api/admin/orders · /api/admin/users · PATCH /api/admin/users/:id | `{role}` | admin only |

## 4. Database schema (PostgreSQL, Drizzle)

`users(id uuid pk, name, email unique-citext(lowercased), password_hash, role enum,
created_at)` · `sessions(id, user_id→users cascade, token_hash unique, expires_at,
created_at)` · `categories(id, slug unique, name, sort_order)` · `products(id,
category_id→categories, name, description, color_hex, garment_template, price_cents,
active, created_at; idx category_id)` · `product_sizes(product_id→products cascade, size,
stock; pk(product_id,size))` · `uploads(id, user_id→users cascade, file_name unique, mime,
width, height, bytes, sha256, created_at; idx user_id)` · `tryon_jobs(id, user_id→users
cascade, upload_id→uploads cascade, product_id→products, size, status enum
queued|processing|completed|failed, error_code, error_message, result_file, landmarks
jsonb, warnings jsonb, processing_ms, created_at, updated_at; idx(user_id,created_at))` ·
`cart_items(id, user_id, product_id, size, qty, added_at; unique(user_id,product_id,size))`
· `wishlist_items(id, user_id, product_id, added_at; unique(user_id,product_id))` ·
`orders(id, user_id, status enum, subtotal/shipping/tax/total _cents, created_at)` ·
`order_items(id, order_id→orders cascade, product_id, size, qty, unit_price_cents)`.

Migrations: `npx drizzle-kit push` (dev) — or `drizzle-kit generate` for SQL files.

## 5. Security & privacy

- Uploads: magic-byte sniffing (extension-blind), ≤ `MAX_UPLOAD_MB`, dimension gates,
  re-encode strips EXIF, random filenames, storage outside web root, traversal-safe reads.
- User photos & results: served only to owner/admin via `/api/files` (`private, no-store`).
  `DELETE /api/uploads/:id` = user-initiated deletion; recommend a nightly retention job
  (delete uploads > 30 days) — where a cron worker would call `deleteStoredFile`.
  Consent copy lives on the upload UI; never train on user photos without opt-in.
- bcrypt(12) · salted; sessions = opaque tokens, only sha256 stored; httpOnly + SameSite=Lax
  + Secure cookies. Login returns identical errors for unknown email vs wrong password.
- In-memory fixed-window rate limits on auth/upload/try-on (Redis INCR/EXPIRE in prod).
- Security headers in `next.config.ts`; no user input reaches `sharp`/fs paths unsanitized;
  no outbound fetch of user-controlled URLs (SSRF-safe: only `TRYON_API_URL` is fetched,
  operator-configured). Admin actions require `role='admin'`; self-demotion blocked.

## 6. Edge cases (all explicit)

no person (422 NO_PERSON) · multiple people (422 MULTIPLE_PEOPLE) · low-res
(422 LOW_RESOLUTION / IMAGE_TOO_SMALL) · non-frontal (200 + `warnings:[NON_FRONTAL_POSE]`)
· unsupported garment (400 UNSUPPORTED_CATEGORY) · out-of-stock size (409 OUT_OF_STOCK with
`details.available` / checkout `{issues[]}`) · expired session (401 AUTH_REQUIRED → UI
redirects to `/login?next=…`) · duplicate email (409 EMAIL_TAKEN) · oversized file (413),
malformed/undecodable (422 MALFORMED_IMAGE), wrong type (415) · gallery deletes backed by
`File` reuse guarding (404 UPLOAD_NOT_FOUND, anti-enumeration) · model failure
(502 MODEL_ERROR) with the job persisted as `failed` for audit.

## 7. Testing

`npx vitest run` — **unit:** totals math, bcrypt roundtrip/salting, mime sniffing +
traversal guard, pose-grid analysis (empty/blank/two-person/asymmetric fixtures), garment
SVG, size-scale monotonicity. **integration:** `tests/pipeline.integration.test.ts` runs the
full preprocess→pose→overlay on sharp-generated fixture photos (incl. NO_PERSON +
LOW_RESOLUTION paths); `tests/cart.integration.test.ts` exercises cart uniqueness, totals,
wishlist idempotency and conditional stock reservation on a real DB (auto-skips without
`DATABASE_URL`). Route-level e2e suggestion: Playwright against the seeded demo account.

## 8. Compatibility

- Browsers: ES2020+, `<input type=file accept>` (iOS/Android pick camera or library —
  `capture` intentionally omitted), `FormData`, `AbortController`, backdrop-filter,
  aspect-ratio. Degrades to system fonts if Google Fonts unreachable.
- Server: Node ≥ 20 (sharp prebuilds). Python sidecar alternative: Python 3.10–3.12,
  `mediapipe` wheels (per platform; no Python 3.13 support yet), OpenCV ≥ 4.8.
- PG ≥ 14. Upload dir must be writable by the app user.

## 9. Roadmap

**MVP (done):** auth+sessions, catalog+sizes+stock, secure upload, heuristic pose →
overlay try-on with before/after + pose debug, cart/wishlist, transactional checkout,
admin console, rate limits, tests.
**Next:** 1) swap in MediaPipe PoseLandmarker landmarks; 2) `TRYON_PROVIDER=http` diffusion
try-on (IDM-VTON-style) behind the existing job queue (make jobs async + poll);
3) size recommendation from `personBox` proportions; 4) live camera capture
(getUserMedia) + AR overlay; 5) background removal for robust segmentation;
6) 3D garment drapes; 7) orders: Stripe + fulfillment states; 8) i18n + RTL;
9) voice assistant for hands-free studio; 10) React Native app sharing the REST API.

## 10. Operation

```bash
cp .env.example .env          # fill DATABASE_URL etc.
npx drizzle-kit push          # create tables
npx tsx scripts/seed.ts       # demo data (admin@virtualfit.dev/admin12345)
npx vitest run                # tests
npm run build && npm start    # production
```
