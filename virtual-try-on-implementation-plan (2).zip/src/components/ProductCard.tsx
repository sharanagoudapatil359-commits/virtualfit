"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { Heart, ScanFace, ShoppingBag } from "lucide-react";
import type { ProductDto } from "@/lib/catalog";
import { money } from "@/lib/constants";
import { useToast } from "@/components/Toast";

export default function ProductCard({
  product,
  wished = false,
  onWishChange,
}: {
  product: ProductDto;
  wished?: boolean;
  onWishChange?: (active: boolean) => void;
}) {
  const router = useRouter();
  const { push } = useToast();
  const [size, setSize] = useState<string | null>(null);
  const [wish, setWish] = useState(wished);
  const [busy, setBusy] = useState(false);

  const guardAuth = async (res: Response): Promise<boolean> => {
    if (res.status === 401) {
      push("Sign in to continue.", "info");
      router.push(`/login?next=${encodeURIComponent("/catalog")}`);
      return false;
    }
    return true;
  };

  const addToCart = async () => {
    if (!size) return push("Pick a size first.", "info");
    setBusy(true);
    const res = await fetch("/api/cart", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ productId: product.id, size, qty: 1 }),
    });
    setBusy(false);
    if (!(await guardAuth(res))) return;
    if (res.ok) push(`${product.name} (${size}) added to cart.`, "success");
    else {
      const j = await res.json().catch(() => null);
      push(j?.error?.message ?? "Could not add to cart.", "error");
    }
  };

  const toggleWish = async () => {
    const res = await fetch("/api/wishlist", {
      method: wish ? "DELETE" : "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ productId: product.id }),
    });
    if (!(await guardAuth(res))) return;
    const next = !wish;
    setWish(next);
    onWishChange?.(next);
    push(next ? "Saved to wishlist." : "Removed from wishlist.", next ? "success" : "info");
  };

  return (
    <div className="group flex flex-col overflow-hidden rounded-3xl border border-white/8 bg-panel transition duration-300 hover:-translate-y-1.5 hover:border-white/15">
      <div
        className="relative aspect-[5/7] overflow-hidden"
        style={{
          background: `radial-gradient(120% 100% at 50% 0%, ${product.colorHex}26 0%, transparent 60%), #161618`,
        }}
      >
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={product.imageUrl}
          alt={product.name}
          className="h-full w-full object-contain p-8 transition duration-500 group-hover:scale-[1.04]"
          loading="lazy"
        />
        <button
          onClick={toggleWish}
          aria-label="Toggle wishlist"
          className={`absolute right-3 top-3 grid h-9 w-9 place-items-center rounded-full border backdrop-blur transition ${
            wish
              ? "border-ember/60 bg-ember/20 text-ember"
              : "border-white/15 bg-ink/40 text-cream/70 hover:text-ember"
          }`}
        >
          <Heart size={15} fill={wish ? "currentColor" : "none"} />
        </button>
        <span className="absolute left-3 top-3 rounded-full bg-ink/60 px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.16em] text-cream/70 backdrop-blur">
          {product.category?.name ?? "Item"}
        </span>
      </div>

      <div className="flex flex-1 flex-col gap-3 p-4">
        <div className="flex items-start justify-between gap-2">
          <h3 className="text-[15px] font-semibold leading-snug">{product.name}</h3>
          <span className="whitespace-nowrap text-sm font-bold text-lime">{money(product.priceCents)}</span>
        </div>
        <p className="line-clamp-2 text-xs leading-relaxed text-mute">{product.description}</p>

        <div className="mt-auto flex flex-wrap gap-1.5">
          {product.sizes.map((s) => {
            const out = s.stock < 1;
            return (
              <button
                key={s.size}
                disabled={out}
                onClick={() => setSize(s.size)}
                title={out ? "Out of stock" : `${s.stock} in stock`}
                className={`h-7 min-w-8 rounded-md border px-1.5 text-[11px] font-semibold transition ${
                  out
                    ? "cursor-not-allowed border-white/5 text-cream/25 line-through"
                    : size === s.size
                      ? "border-lime bg-lime text-ink"
                      : "border-white/15 text-cream/70 hover:border-cream/40"
                }`}
              >
                {s.size}
              </button>
            );
          })}
        </div>

        <div className="flex gap-2 pt-1">
          <button
            onClick={addToCart}
            disabled={busy}
            className="flex flex-1 items-center justify-center gap-1.5 rounded-full bg-cream py-2 text-xs font-bold uppercase tracking-[0.08em] text-ink transition hover:bg-lime disabled:opacity-50"
          >
            <ShoppingBag size={13} /> Add
          </button>
          <button
            onClick={() => router.push(`/tryon?product=${product.id}`)}
            className="flex items-center justify-center gap-1.5 rounded-full border border-violet/50 px-3.5 py-2 text-xs font-bold uppercase tracking-[0.08em] text-violet transition hover:bg-violet/15"
          >
            <ScanFace size={13} /> Try
          </button>
        </div>
      </div>
    </div>
  );
}
