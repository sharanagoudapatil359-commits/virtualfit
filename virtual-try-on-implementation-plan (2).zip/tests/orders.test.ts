import { describe, expect, it } from "vitest";
import {
  computeTotals,
  FREE_SHIPPING_THRESHOLD,
  SHIPPING_FLAT,
} from "@/lib/orders";

describe("computeTotals", () => {
  it("empty cart → all zeros", () => {
    expect(computeTotals([])).toEqual({
      subtotalCents: 0,
      shippingCents: 0,
      taxCents: 0,
      totalCents: 0,
    });
  });

  it("charges flat shipping below the free threshold", () => {
    const t = computeTotals([{ unitPriceCents: 1000, qty: 1 }]);
    expect(t.shippingCents).toBe(SHIPPING_FLAT);
    expect(t.totalCents).toBe(1000 + SHIPPING_FLAT + Math.round(1000 * 0.08));
  });

  it("free shipping exactly at the threshold", () => {
    const t = computeTotals([
      { unitPriceCents: FREE_SHIPPING_THRESHOLD / 2, qty: 2 },
    ]);
    expect(t.subtotalCents).toBe(FREE_SHIPPING_THRESHOLD);
    expect(t.shippingCents).toBe(0);
  });

  it("multiplies qty into the subtotal", () => {
    const t = computeTotals([{ unitPriceCents: 999, qty: 3 }]);
    expect(t.subtotalCents).toBe(2997);
    expect(t.taxCents).toBe(Math.round(2997 * 0.08));
  });
});
