import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { orderItems, orders, products, users } from "@/db/schema";
import { handler, ok } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";

/** GET /api/admin/orders — all orders, newest first, with buyer + items. */
export const GET = handler(async () => {
  await requireAdmin();
  const list = await db
    .select({ o: orders, email: users.email, name: users.name })
    .from(orders)
    .innerJoin(users, eq(users.id, orders.userId))
    .orderBy(desc(orders.createdAt))
    .limit(100);

  const result = await Promise.all(
    list.map(async ({ o, email, name }) => {
      const items = await db
        .select({
          size: orderItems.size,
          qty: orderItems.qty,
          unitPriceCents: orderItems.unitPriceCents,
          name: products.name,
        })
        .from(orderItems)
        .innerJoin(products, eq(products.id, orderItems.productId))
        .where(eq(orderItems.orderId, o.id));
      return {
        id: o.id,
        status: o.status,
        totalCents: o.totalCents,
        createdAt: o.createdAt.toISOString(),
        customer: { name, email },
        items,
      };
    }),
  );
  return ok({ orders: result });
});
