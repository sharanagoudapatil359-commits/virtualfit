import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { uploads } from "@/db/schema";
import { ApiError, handler, ok } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { deleteStoredFile } from "@/lib/uploads";

type Ctx = { params: Promise<{ id: string }> };

/** DELETE /api/uploads/:id — privacy: users can delete their own photos. */
export const DELETE = handler(async (_req: Request, ctx: Ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const cond =
    user.role === "admin"
      ? eq(uploads.id, id)
      : and(eq(uploads.id, id), eq(uploads.userId, user.id));
  const [row] = await db.delete(uploads).where(cond).returning();
  if (!row) throw new ApiError(404, "UPLOAD_NOT_FOUND", "Upload not found.");
  await deleteStoredFile(row.fileName, "upload");
  return ok({ deleted: true });
});
