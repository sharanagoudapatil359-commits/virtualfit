import { and, desc, eq, gte, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  cartItems,
  orderItems,
  orders,
  products,
  productSizes,
} from "@/db/schema";
import { ApiError, handler, ok } from "@/lib/api";
import { requireUser } from "@/lib/auth";
import { computeTotals } from "@/lib/orders";

/**
 * POST /api/orders — checkout from the server-side cart.
 * Transactional: every stock decrement is conditional (stock >= qty);
 * if any item fails, the whole transaction rolls back → 409 with detail.
 */
export const POST = handler(async () => {
  const user = await requireUser();

  const cart = await db
    .select({
      id: cartItems.id,
      productId: cartItems.productId,
      size: cartItems.size,
      qty: cartItems.qty,
      priceCents: products.priceCents,
      name: products.name,
    })
    .from(cartItems)
    .innerJoin(products, eq(products.id, cartItems.productId))
    .where(eq(cartItems.userId, user.id));

  if (cart.length === 0)
    throw new ApiError(400, "CART_EMPTY", "Your cart is empty.");

  const totals = computeTotals(
    cart.map((c) => ({ unitPriceCents: c.priceCents, qty: c.qty })),
  );

  const order = await db.transaction(async (tx) => {
    const issues: { productId: string; size: string; available: number }[] = [];
    for (const item of cart) {
      const updated = await tx
        .update(productSizes)
        .set({ stock: sql`${productSizes.stock} - ${item.qty}` })
        .where(
          and(
            eq(productSizes.productId, item.productId),
            eq(productSizes.size, item.size),
            gte(productSizes.stock, item.qty),
          ),
        )
        .returning({ stock: productSizes.stock });
      if (updated.length === 0) {
        const [cur] = await tx
          .select({ stock: productSizes.stock })
          .from(productSizes)
          .where(
            and(
              eq(productSizes.productId, item.productId),
              eq(productSizes.size, item.size),
            ),
          )
          .limit(1);
        issues.push({
          productId: item.productId,
          size: item.size,
          available: cur?.stock ?? 0,
        });
      }
    }
    if (issues.length > 0)
      throw new ApiError(
        409,
        "OUT_OF_STOCK",
        "Some items no longer have enough stock.",
        { issues },
      );

    const [created] = await tx
      .insert(orders)
      .values({
        userId: user.id,
        status: "placed",
        subtotalCents: totals.subtotalCents,
        shippingCents: totals.shippingCents,
        taxCents: totals.taxCents,
        totalCents: totals.totalCents,
      })
      .returning();

    await tx.insert(orderItems).values(
      cart.map((c) => ({
        orderId: created.id,
        productId: c.productId,
        size: c.size,
        qty: c.qty,
        unitPriceCents: c.priceCents,
      })),
    );
    await tx.delete(cartItems).where(eq(cartItems.userId, user.id));
    return created;
  });

  return ok(
    { order: { id: order.id, status: order.status, totalCents: order.totalCents } },
    201,
  );
});

/** GET /api/orders — order history with line items. */
export const GET = handler(async () => {
  const user = await requireUser();
  const list = await db
    .select()
    .from(orders)
    .where(eq(orders.userId, user.id))
    .orderBy(desc(orders.createdAt))
    .limit(20);

  const withItems = await Promise.all(
    list.map(async (o) => {
      const rows = await db
        .select({
          size: orderItems.size,
          qty: orderItems.qty,
          unitPriceCents: orderItems.unitPriceCents,
          name: products.name,
        })
        .from(orderItems)
        .innerJoin(products, eq(products.id, orderItems.productId))
        .where(eq(orderItems.orderId, o.id));
      return {
        id: o.id,
        status: o.status,
        totalCents: o.totalCents,
        createdAt: o.createdAt.toISOString(),
        items: rows,
      };
    }),
  );
  return ok({ orders: withItems });
});
