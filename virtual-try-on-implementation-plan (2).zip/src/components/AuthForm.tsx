"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { ArrowRight, Loader2 } from "lucide-react";

interface FieldError { path: string; message: string }

function Form({ mode }: { mode: "login" | "register" }) {
  const router = useRouter();
  const params = useSearchParams();
  const next = params.get("next") || (mode === "register" ? "/tryon" : "/");

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [fields, setFields] = useState<FieldError[]>([]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    setFields([]);
    const res = await fetch(`/api/auth/${mode}`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(mode === "register" ? { name, email, password } : { email, password }),
    });
    setBusy(false);
    if (res.ok) {
      router.refresh();
      router.push(next);
      return;
    }
    const j = await res.json().catch(() => null);
    setError(j?.error?.message ?? "Something went wrong.");
    setFields(j?.error?.details?.fields ?? []);
  };

  const fieldHint = (p: string) => fields.find((f) => f.path === p)?.message;

  return (
    <form onSubmit={submit} className="mt-8 flex flex-col gap-4">
      {mode === "register" && (
        <div>
          <label className="mb-1.5 block text-xs font-semibold uppercase tracking-[0.14em] text-mute">
            Name
          </label>
          <input
            className="input"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Alex Rivera"
            autoComplete="name"
            required
          />
          {fieldHint("name") && <p className="mt-1 text-xs text-ember">{fieldHint("name")}</p>}
        </div>
      )}
      <div>
        <label className="mb-1.5 block text-xs font-semibold uppercase tracking-[0.14em] text-mute">
          Email
        </label>
        <input
          className="input"
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="you@example.com"
          autoComplete="email"
          required
        />
        {fieldHint("email") && <p className="mt-1 text-xs text-ember">{fieldHint("email")}</p>}
      </div>
      <div>
        <label className="mb-1.5 block text-xs font-semibold uppercase tracking-[0.14em] text-mute">
          Password {mode === "register" && <span className="text-cream/30">(8+ chars)</span>}
        </label>
        <input
          className="input"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="••••••••"
          autoComplete={mode === "register" ? "new-password" : "current-password"}
          required
        />
        {fieldHint("password") && <p className="mt-1 text-xs text-ember">{fieldHint("password")}</p>}
      </div>

      {error && (
        <p className="rounded-xl border border-ember/40 bg-ember/10 px-4 py-2.5 text-sm text-ember">
          {error}
        </p>
      )}

      <button
        type="submit"
        disabled={busy}
        className="mt-2 inline-flex items-center justify-center gap-2 rounded-full bg-lime py-3 text-sm font-bold uppercase tracking-[0.1em] text-ink transition hover:bg-cream disabled:opacity-60"
      >
        {busy && <Loader2 size={15} className="animate-spin" />}
        {mode === "register" ? "Create account" : "Sign in"}
        {!busy && <ArrowRight size={15} />}
      </button>
    </form>
  );
}

export default function AuthForm({ mode }: { mode: "login" | "register" }) {
  return (
    <div className="mx-auto max-w-md px-5 py-14">
      <p className="text-[11px] font-semibold uppercase tracking-[0.24em] text-violet">
        {mode === "register" ? "Join Virtual Fit" : "Welcome back"}
      </p>
      <h1 className="mt-2 font-display text-3xl font-extrabold">
        {mode === "register" ? "Create your account" : "Sign in"}
      </h1>
      <p className="mt-3 text-sm text-mute">
        {mode === "register"
          ? "Upload photos are private to your account. Delete them anytime."
          : "New here? "}
        {mode === "login" && (
          <Link href="/register" className="text-lime hover:underline">
            Create an account
          </Link>
        )}
      </p>
      <Suspense>
        <Form mode={mode} />
      </Suspense>
      {mode === "register" && (
        <p className="mt-5 text-center text-sm text-mute">
          Already have one?{" "}
          <Link href="/login" className="text-lime hover:underline">
            Sign in
          </Link>
        </p>
      )}
    </div>
  );
}
