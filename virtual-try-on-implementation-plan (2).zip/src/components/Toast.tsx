"use client";

import { createContext, useCallback, useContext, useRef, useState, type ReactNode } from "react";
import { AlertTriangle, CheckCircle2, Info } from "lucide-react";

type Kind = "success" | "error" | "info";
interface ToastItem { id: number; kind: Kind; msg: string }

const ToastCtx = createContext<{ push: (msg: string, kind?: Kind) => void }>({
  push: () => {},
});

export const useToast = () => useContext(ToastCtx);

const ICONS: Record<Kind, ReactNode> = {
  success: <CheckCircle2 size={16} className="text-lime" />,
  error: <AlertTriangle size={16} className="text-ember" />,
  info: <Info size={16} className="text-violet" />,
};
const RING: Record<Kind, string> = {
  success: "border-lime/40",
  error: "border-ember/40",
  info: "border-violet/40",
};

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ToastItem[]>([]);
  const idRef = useRef(0);

  const push = useCallback((msg: string, kind: Kind = "info") => {
    const id = ++idRef.current;
    setItems((xs) => [...xs.slice(-3), { id, kind, msg }]);
    setTimeout(() => setItems((xs) => xs.filter((t) => t.id !== id)), 3600);
  }, []);

  return (
    <ToastCtx.Provider value={{ push }}>
      {children}
      <div className="pointer-events-none fixed bottom-5 left-1/2 z-[80] flex w-[92vw] max-w-md -translate-x-1/2 flex-col gap-2">
        {items.map((t) => (
          <div
            key={t.id}
            className={`pointer-events-auto flex items-center gap-2.5 rounded-xl border bg-panel-2/95 px-4 py-3 text-sm shadow-2xl backdrop-blur ${RING[t.kind]}`}
            role="status"
          >
            {ICONS[t.kind]}
            <span className="text-cream/90">{t.msg}</span>
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}
