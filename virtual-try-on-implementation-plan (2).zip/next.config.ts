import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /** Baseline security headers for every response.
   *
   *  NOTE: X-Frame-Options / CSP frame-ancestors are intentionally NOT set —
   *  they would DENY the page from rendering inside this platform's
   *  iframe-based preview. For a self-hosted production deployment, add:
   *    { key: "X-Frame-Options", value: "DENY" }
   *  (or a CSP "frame-ancestors 'self'" directive).
   */
  async headers() {
    return [
      {
        source: "/:path*",
        headers: [
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          { key: "Permissions-Policy", value: "camera=(self), microphone=(), geolocation=()" },
        ],
      },
    ];
  },
};

export default nextConfig;
