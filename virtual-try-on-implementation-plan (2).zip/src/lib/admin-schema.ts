import { z } from "zod";
import { GARMENT_TEMPLATES, SIZES } from "@/lib/constants";

export const productInputSchema = z.object({
  name: z.string().trim().min(2).max(80),
  categoryId: z.string().uuid(),
  description: z.string().max(600).default(""),
  colorHex: z
    .string()
    .regex(/^#([0-9a-fA-F]{6}|[0-9a-fA-F]{3})$/, "Use a hex colour like #4C6FFF"),
  garmentTemplate: z.enum(GARMENT_TEMPLATES),
  priceCents: z.number().int().min(100).max(10_000_000),
  sizes: z
    .array(
      z.object({
        size: z.enum(SIZES),
        stock: z.number().int().min(0).max(100_000),
      }),
    )
    .min(1),
});

export const productPatchSchema = productInputSchema.partial();
