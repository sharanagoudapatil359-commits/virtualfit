import sharp from "sharp";

/**
 * Heuristic pose detector (MVP stand-in for MediaPipe Pose).
 *
 * Segments the subject from the background by estimating the background
 * colour from border pixels, builds a coarse occupancy grid, then derives
 * body landmark proportions from the subject bounding box and per-row
 * widths. The exported interface matches what a MediaPipe-backed
 * implementation would return, so it can be swapped without touching
 * callers — see docs/ARCHITECTURE.md ("Swapping in MediaPipe").
 *
 * Graceful failures use PoseError codes consumed by the API layer:
 *   LOW_RESOLUTION | NO_PERSON | MULTIPLE_PEOPLE | UNCLEAR_POSE
 */

export type Point = { x: number; y: number };

export interface PoseLandmarks {
  neck: Point;
  leftShoulder: Point;
  rightShoulder: Point;
  chest: Point;
  waist: Point;
  leftHip: Point;
  rightHip: Point;
  leftKnee: Point;
  rightKnee: Point;
  leftAnkle: Point;
  rightAnkle: Point;
}

export interface PoseResult {
  landmarks: PoseLandmarks;
  personBox: { x: number; y: number; width: number; height: number };
  confidence: number; // 0..1
  frontality: number; // 0..1 (1 = facing camera)
  warnings: string[]; // NON_FRONTAL_POSE | LOW_CONFIDENCE
}

export type PoseErrorCode =
  | "LOW_RESOLUTION"
  | "NO_PERSON"
  | "MULTIPLE_PEOPLE"
  | "UNCLEAR_POSE";

export class PoseError extends Error {
  constructor(
    public code: PoseErrorCode,
    message: string,
  ) {
    super(message);
  }
}

/** Fractions of body height (top of head = 0) for landmark rows. */
const ROW = {
  shoulder: 0.17,
  chest: 0.25,
  waist: 0.38,
  hip: 0.49,
  knee: 0.71,
  ankle: 0.92,
} as const;

const GRID_W = 48;
const BG_THRESHOLD = 38; // RGB distance from estimated background
const MIN_FG_RATIO = 0.05;
const MAX_FG_RATIO = 0.93;

function dilate(mask: Uint8Array, W: number, H: number): Uint8Array {
  const out = new Uint8Array(mask.length);
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      if (!mask[y * W + x]) continue;
      for (let dy = -1; dy <= 1; dy++)
        for (let dx = -1; dx <= 1; dx++) {
          const nx = x + dx;
          const ny = y + dy;
          if (nx >= 0 && nx < W && ny >= 0 && ny < H) out[ny * W + nx] = 1;
        }
    }
  }
  return out;
}

/** Count large connected components (best-effort multi-person detection). */
function countPersonBlobs(mask: Uint8Array, W: number, H: number, fg: number): number {
  const seen = new Uint8Array(mask.length);
  let persons = 0;
  const minSize = fg * 0.15;
  const minHeight = H * 0.25;
  for (let i = 0; i < mask.length; i++) {
    if (!mask[i] || seen[i]) continue;
    // BFS
    let size = 0,
      minY = H,
      maxY = 0;
    const stack = [i];
    seen[i] = 1;
    while (stack.length) {
      const cur = stack.pop()!;
      size++;
      const cx = cur % W;
      const cy = (cur / W) | 0;
      if (cy < minY) minY = cy;
      if (cy > maxY) maxY = cy;
      for (const n of [cur - 1, cur + 1, cur - W, cur + W]) {
        if (n < 0 || n >= mask.length) continue;
        if ((cur % W === 0 && n === cur - 1) || (cur % W === W - 1 && n === cur + 1))
          continue;
        if (mask[n] && !seen[n]) {
          seen[n] = 1;
          stack.push(n);
        }
      }
    }
    if (size >= minSize && maxY - minY >= minHeight) persons++;
  }
  return persons;
}

/** Width (in grid columns) of the foreground at a given body-row fraction. */
function rowSpan(
  mask: Uint8Array,
  W: number,
  H: number,
  y: number,
): { left: number; right: number } | null {
  const gy = Math.max(0, Math.min(H - 1, Math.round(y)));
  let left = -1,
    right = -1,
    count = 0;
  for (let x = 0; x < W; x++) {
    if (mask[gy * W + x]) {
      if (left < 0) left = x;
      right = x;
      count++;
    }
  }
  if (count < 2) return null;
  return { left, right };
}

/**
 * Pure grid → landmarks analysis. Exported separately so unit tests can
 * drive it with synthetic masks (no image decoding needed).
 */
export function analyzeMask(
  mask: Uint8Array,
  W: number,
  H: number,
  imgW: number,
  imgH: number,
): PoseResult {
  let fg = 0;
  for (let i = 0; i < mask.length; i++) fg += mask[i];
  const ratio = fg / mask.length;
  if (ratio < MIN_FG_RATIO)
    throw new PoseError(
      "NO_PERSON",
      "No person detected. Stand 1.5-2m from the camera against a plain background.",
    );
  if (ratio > MAX_FG_RATIO)
    throw new PoseError(
      "NO_PERSON",
      "Could not isolate you from the background. Use a plainer backdrop and contrasting clothes.",
    );

  // Best-effort multi-person guard (dilated to merge limbs with torsos).
  const persons = countPersonBlobs(dilate(mask, W, H), W, H, fg);
  if (persons > 1)
    throw new PoseError(
      "MULTIPLE_PEOPLE",
      "More than one person detected. Please upload a solo full-body photo.",
    );

  // Subject bounding box
  let minX = W,
    maxX = 0,
    minY = H,
    maxY = 0;
  for (let y = 0; y < H; y++)
    for (let x = 0; x < W; x++)
      if (mask[y * W + x]) {
        if (x < minX) minX = x;
        if (x > maxX) maxX = x;
        if (y < minY) minY = y;
        if (y > maxY) maxY = y;
      }
  const boxW = maxX - minX + 1;
  const boxH = maxY - minY + 1;
  const sx = imgW / W; // grid → image scale
  const sy = imgH / H;

  const box = {
    x: minX * sx,
    y: minY * sy,
    width: boxW * sx,
    height: boxH * sy,
  };

  const at = (frac: number) => minY + frac * boxH; // grid row
  const ix = (gx: number) => (gx + 0.5) * sx;
  const iy = (gy: number) => gy * sy;
  const cx = (minX + boxW / 2) * sx;

  const fallback = (fracOfBox: number) => ({
    left: minX + (boxW - boxW * fracOfBox) / 2,
    right: minX + (boxW + boxW * fracOfBox) / 2,
  });
  const span = (frac: number, fb: number) =>
    rowSpan(mask, W, H, at(frac)) ?? fallback(fb);

  const shoulder = span(ROW.shoulder, 0.86);
  const waist = span(ROW.waist, 0.7);
  const hip = span(ROW.hip, 0.78);

  const landmarks: PoseLandmarks = {
    neck: { x: cx, y: iy(at(0.13)) },
    leftShoulder: { x: ix(shoulder.left), y: iy(at(ROW.shoulder)) },
    rightShoulder: { x: ix(shoulder.right), y: iy(at(ROW.shoulder)) },
    chest: { x: cx, y: iy(at(ROW.chest)) },
    waist: { x: cx, y: iy(at(ROW.waist)) },
    leftHip: { x: ix(hip.left), y: iy(at(ROW.hip)) },
    rightHip: { x: ix(hip.right), y: iy(at(ROW.hip)) },
    leftKnee: { x: (minX + boxW * 0.32) * sx, y: iy(at(ROW.knee)) },
    rightKnee: { x: (minX + boxW * 0.68) * sx, y: iy(at(ROW.knee)) },
    leftAnkle: { x: (minX + boxW * 0.34) * sx, y: iy(at(ROW.ankle)) },
    rightAnkle: { x: (minX + boxW * 0.66) * sx, y: iy(at(ROW.ankle)) },
  };

  // Frontality: mid-line stability between the shoulder band and hip band.
  // A frontal pose keeps both row-centres on the same axis; turning sideways
  // shifts the torso mass off-axis.
  const rowMid = (s: { left: number; right: number }) => (s.left + s.right + 1) / 2;
  const offsetRatio = Math.abs(rowMid(shoulder) - rowMid(hip)) / Math.max(1, boxW);
  const frontality = Math.max(0, Math.min(1, 1 - offsetRatio * 3));

  const aspect = boxH / Math.max(1, boxW);
  let confidence = 0.35;
  if (ratio >= 0.08 && ratio <= 0.6) confidence += 0.2;
  if (aspect >= 1.5 && aspect <= 4.5) confidence += 0.15;
  if (rowSpan(mask, W, H, at(ROW.shoulder)) && rowSpan(mask, W, H, at(ROW.hip)))
    confidence += 0.15;
  if (frontality > 0.6) confidence += 0.15;
  confidence = Math.min(1, confidence);

  const warnings: string[] = [];
  if (frontality < 0.55) warnings.push("NON_FRONTAL_POSE");
  if (confidence < 0.55) warnings.push("LOW_CONFIDENCE");
  if (confidence < 0.4)
    throw new PoseError(
      "UNCLEAR_POSE",
      "Could not map body landmarks. Use a sharper, well-lit, front-facing full-body photo.",
    );

  return { landmarks, personBox: box, confidence, frontality, warnings };
}

/** Decode → orient → downscale → segment → analyse. */
export async function detectPose(image: Buffer): Promise<PoseResult> {
  const oriented = await sharp(image).rotate().toBuffer();
  const meta = await sharp(oriented).metadata();
  const imgW = meta.width ?? 0;
  const imgH = meta.height ?? 0;
  if (imgW < config0.minImageWidth || imgH < config0.minImageHeight)
    throw new PoseError(
      "LOW_RESOLUTION",
      `Photo is ${imgW}x${imgH}px — too small. Upload at least ${config0.minImageWidth}x${config0.minImageHeight}px.`,
    );

  const H = Math.max(
    32,
    Math.min(112, Math.round((GRID_W * imgH) / Math.max(1, imgW))),
  );
  const raw = await sharp(oriented)
    .resize(GRID_W, H, { fit: "fill" })
    .raw()
    .toBuffer();

  // Background colour = per-channel median of the border ring.
  const ch = 3;
  const border: number[][] = [[], [], []];
  const px = (x: number, y: number) => (y * GRID_W + x) * ch;
  for (let y = 0; y < H; y++)
    for (let x = 0; x < GRID_W; x++) {
      if (y > 1 && y < H - 2 && x > 1 && x < GRID_W - 2) continue;
      const o = px(x, y);
      border[0].push(raw[o]);
      border[1].push(raw[o + 1]);
      border[2].push(raw[o + 2]);
    }
  const median = (a: number[]) => {
    const s = [...a].sort((p, q) => p - q);
    return s[s.length >> 1];
  };
  const bg = [median(border[0]), median(border[1]), median(border[2])];

  const mask = new Uint8Array(GRID_W * H);
  for (let i = 0; i < GRID_W * H; i++) {
    const o = i * ch;
    const d = Math.max(
      Math.abs(raw[o] - bg[0]),
      Math.abs(raw[o + 1] - bg[1]),
      Math.abs(raw[o + 2] - bg[2]),
    );
    mask[i] = d > BG_THRESHOLD ? 1 : 0;
  }
  return analyzeMask(mask, GRID_W, H, imgW, imgH);
}

// Local copy of resolution limits (kept import-free so tests can run
// pose logic without loading the full config/env module).
const config0 = { minImageWidth: 480, minImageHeight: 560 };
