import { eq, sql } from "drizzle-orm";
import { db } from "./index";
import { categories, products, productSizes, users } from "./schema";
import { SIZES } from "../lib/constants";
import { hashPassword } from "../lib/password";

/** Shared seed data + idempotent ensureSeed(), used by scripts/seed.ts AND
 *  the runtime bootstrap (instrumentation.ts) so a fresh environment always
 *  has a working catalog + demo accounts. */

export const SEED_CATEGORIES = [
  { slug: "tops", name: "Tops", sortOrder: 1 },
  { slug: "dresses", name: "Dresses", sortOrder: 2 },
  { slug: "pants", name: "Pants", sortOrder: 3 },
  { slug: "skirts", name: "Skirts", sortOrder: 4 },
  { slug: "outerwear", name: "Outerwear", sortOrder: 5 },
];

export const SEED_PRODUCTS: {
  cat: string;
  name: string;
  description: string;
  colorHex: string;
  template: "tee" | "dress" | "pants" | "skirt" | "jacket";
  priceCents: number;
  zeroSizes?: string[];
}[] = [
  { cat: "tops", name: "Aura Linen Tee", description: "Relaxed heavyweight linen jersey with a dropped shoulder.", colorHex: "#E8E3D5", template: "tee", priceCents: 3900 },
  { cat: "tops", name: "Nova Ribbed Tank", description: "Second-skin rib knit in ultraviolet.", colorHex: "#8B7CFF", template: "tee", priceCents: 2900 },
  { cat: "tops", name: "Onyx Boxy Tee", description: "Cropped box cut in deep onyx cotton.", colorHex: "#2A2A2F", template: "tee", priceCents: 3200, zeroSizes: ["XS"] },
  { cat: "dresses", name: "Sable Slip Dress", description: "Bias-cut matte satin with adjustable straps.", colorHex: "#41414B", template: "dress", priceCents: 8900 },
  { cat: "dresses", name: "Ember Midi Dress", description: "Terracotta crepe with a sculpted waist seam.", colorHex: "#C4573B", template: "dress", priceCents: 9900 },
  { cat: "dresses", name: "Solstice Wrap Dress", description: "Fluid wrap silhouette in washed sage.", colorHex: "#7FA6A3", template: "dress", priceCents: 9600, zeroSizes: ["XXL"] },
  { cat: "pants", name: "Draft Wide Trouser", description: "High-rise wide leg with pressed crease.", colorHex: "#3A3C40", template: "pants", priceCents: 7400 },
  { cat: "pants", name: "Kiln Straight Denim", description: "Rigid mid-blue denim, straight leg.", colorHex: "#4A5D7E", template: "pants", priceCents: 6800, zeroSizes: ["XS", "XXL"] },
  { cat: "skirts", name: "Arc Pleated Skirt", description: "Knife pleats in soft lilac twill.", colorHex: "#D9C8E9", template: "skirt", priceCents: 5600 },
  { cat: "outerwear", name: "Volt Field Jacket", description: "Wearable high-vis shell with storm placket.", colorHex: "#B9C93E", template: "jacket", priceCents: 12900 },
  { cat: "outerwear", name: "Mono Shell Jacket", description: "Minimal 3-layer shell in slate.", colorHex: "#5A6472", template: "jacket", priceCents: 14200 },
];

/** Deterministic per-size stock (index-derived), some sizes out of stock. */
function stockFor(_size: string, i: number, zeroSizes?: string[]) {
  if (zeroSizes?.includes(_size)) return 0;
  return 5 + ((i * 3) % 8);
}

export async function ensureSeed(): Promise<void> {
  // Serialize concurrent bootstraps.
  await db.execute(sql`SELECT pg_advisory_lock(727272)`);
  try {
    const existing = await db.select().from(categories).limit(1);
    if (existing.length === 0) {
      const catIds = new Map<string, string>();
      for (const c of SEED_CATEGORIES) {
        const [row] = await db.insert(categories).values(c).returning();
        catIds.set(c.slug, row.id);
      }
      for (const [i, p] of SEED_PRODUCTS.entries()) {
        const [row] = await db
          .insert(products)
          .values({
            categoryId: catIds.get(p.cat)!,
            name: p.name,
            description: p.description,
            colorHex: p.colorHex,
            garmentTemplate: p.template,
            priceCents: p.priceCents,
          })
          .returning();
        await db.insert(productSizes).values(
          SIZES.map((size, si) => ({
            productId: row.id,
            size,
            stock: stockFor(size, i + si, p.zeroSizes),
          })),
        );
      }
      console.log("[seed] catalog seeded.");
    }

    const ensureUser = async (name: string, email: string, pw: string, role: "user" | "admin") => {
      const [found] = await db.select({ id: users.id }).from(users).where(eq(users.email, email)).limit(1);
      if (found) return;
      await db.insert(users).values({ name, email, role, passwordHash: await hashPassword(pw) });
      console.log(`[seed] created ${email} (${role}).`);
    };
    await ensureUser("Virtual Admin", "admin@virtualfit.dev", "admin12345", "admin");
    await ensureUser("Demo Model", "demo@virtualfit.dev", "demo12345", "user");
  } finally {
    await db.execute(sql`SELECT pg_advisory_unlock(727272)`);
  }
}
