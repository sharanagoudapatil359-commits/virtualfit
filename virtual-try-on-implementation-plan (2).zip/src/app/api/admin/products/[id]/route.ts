import { eq } from "drizzle-orm";
import { db } from "@/db";
import { categories, products, productSizes } from "@/db/schema";
import { ApiError, handler, ok, parseBody } from "@/lib/api";
import { requireAdmin } from "@/lib/auth";
import { productPatchSchema } from "@/lib/admin-schema";
import { attachSizes } from "@/lib/catalog";

type Ctx = { params: Promise<{ id: string }> };

export const PATCH = handler(async (req: Request, ctx: Ctx) => {
  await requireAdmin();
  const { id } = await ctx.params;
  const body = await parseBody(req, productPatchSchema);

  const updated = await db.transaction(async (tx) => {
    const { sizes, ...fields } = body;
    const set: Record<string, unknown> = { ...fields };
    if (fields.garmentTemplate === undefined) delete set.garmentTemplate;
    const [p] = await tx
      .update(products)
      .set(set)
      .where(eq(products.id, id))
      .returning();
    if (!p) return null;
    if (sizes) {
      await tx.delete(productSizes).where(eq(productSizes.productId, id));
      await tx
        .insert(productSizes)
        .values(sizes.map((s) => ({ productId: id, size: s.size, stock: s.stock })));
    }
    return p;
  });
  if (!updated) throw new ApiError(404, "PRODUCT_NOT_FOUND", "Product not found.");
  const [cat] = await db
    .select()
    .from(categories)
    .where(eq(categories.id, updated.categoryId))
    .limit(1);
  const [dto] = await attachSizes([{ p: updated, c: cat ?? null }]);
  return ok({ product: dto });
});
