import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { users } from "@/db/schema";
import { ApiError, handler, ok, parseBody } from "@/lib/api";
import { createSession, publicUser, verifyPassword } from "@/lib/auth";
import { config } from "@/lib/config";
import { clientIp, rateLimit } from "@/lib/ratelimit";

const loginSchema = z.object({
  email: z.string().trim().email().max(120),
  password: z.string().min(1).max(72),
});

export const POST = handler(async (req: Request) => {
  rateLimit(`auth:${clientIp(req)}`, config.limits.auth, 10 * 60 * 1000);
  const body = await parseBody(req, loginSchema);

  const [user] = await db
    .select()
    .from(users)
    .where(eq(users.email, body.email.toLowerCase()))
    .limit(1);

  // Same message either way → no user enumeration.
  const valid = user ? await verifyPassword(body.password, user.passwordHash) : false;
  if (!user || !valid)
    throw new ApiError(401, "INVALID_CREDENTIALS", "Email or password is incorrect.");

  await createSession(user.id);
  return ok({ user: publicUser(user) });
});
