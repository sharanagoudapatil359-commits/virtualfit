import { describe, expect, it } from "vitest";
import { readStoredFile, sniffMime } from "@/lib/uploads";

const JPEG = Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0x41, 0x42]);
const PNG = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 9, 9, 9, 9]);
const WEBP = Buffer.from("RIFF\x00\x00\x00\x00WEBPVP8 ", "latin1");

describe("sniffMime (magic bytes, extension-blind)", () => {
  it("detects jpeg/png/webp", () => {
    expect(sniffMime(JPEG)).toBe("image/jpeg");
    expect(sniffMime(PNG)).toBe("image/png");
    expect(sniffMime(WEBP)).toBe("image/webp");
  });
  it("rejects executables & empty buffers", () => {
    expect(sniffMime(Buffer.from("MZ" + "0".repeat(32)))).toBeNull();
    expect(sniffMime(Buffer.alloc(0))).toBeNull();
  });
});

describe("readStoredFile path safety", () => {
  it("blocks traversal attempts", async () => {
    expect(await readStoredFile("../../etc/passwd", "upload")).toBeNull();
    expect(await readStoredFile("..%2F..%2Fsecret", "upload")).toBeNull();
    expect(await readStoredFile("a/b/c.jpg", "upload")).toBeNull();
  });
  it("returns null for unknown names", async () => {
    expect(await readStoredFile("u_does-not-exist.jpg", "upload")).toBeNull();
  });
});
