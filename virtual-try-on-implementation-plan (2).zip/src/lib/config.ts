import path from "path";

/** Central runtime configuration — every setting is env-driven. */
export const config = {
  /** Directory for user photos + try-on results. OUTSIDE the web root. */
  uploadDir: path.resolve(process.cwd(), process.env.UPLOAD_DIR ?? "uploads"),
  maxUploadBytes: Number(process.env.MAX_UPLOAD_MB ?? 8) * 1024 * 1024,
  minImageWidth: 480,
  minImageHeight: 560,
  maxImageDim: 4096,
  /** "overlay" (built-in) | "http" (hosted try-on model / sidecar). */
  tryonProvider: (process.env.TRYON_PROVIDER ?? "overlay") as
    | "overlay"
    | "http",
  tryonApiUrl: process.env.TRYON_API_URL ?? "",
  tryonApiKey: process.env.TRYON_API_KEY ?? "",
  sessionTtlDays: 14,
  bcryptRounds: 12,
  cookieName: "vf_session",
  limits: {
    auth: Number(process.env.RATE_LIMIT_AUTH ?? 10),
    tryon: Number(process.env.RATE_LIMIT_TRYON ?? 20),
    upload: Number(process.env.RATE_LIMIT_UPLOAD ?? 20),
  },
};

export const resultsDir = () => path.join(config.uploadDir, "results");
