/** Size labels supported MVP-wide. */
export const SIZES = ["XS", "S", "M", "L", "XL", "XXL"] as const;
export type SizeLabel = (typeof SIZES)[number];

/** Garment silhouette templates the overlay renderer supports. */
export const GARMENT_TEMPLATES = [
  "tee",
  "dress",
  "pants",
  "skirt",
  "jacket",
] as const;
export type GarmentTemplate = (typeof GARMENT_TEMPLATES)[number];

/** Which body region a template anchors to. */
export const TEMPLATE_REGION: Record<GarmentTemplate, "upper" | "lower" | "full"> = {
  tee: "upper",
  jacket: "upper",
  dress: "full",
  pants: "lower",
  skirt: "lower",
};

/** Per-size fit scale applied to garment overlay width. */
export const SIZE_SCALE: Record<SizeLabel, number> = {
  XS: 0.9,
  S: 0.95,
  M: 1,
  L: 1.07,
  XL: 1.15,
  XXL: 1.24,
};

export const money = (cents: number): string =>
  `$${(cents / 100).toFixed(2)}`;
